"""Thread-safe append-only event stream with Server-Sent Events semantics."""

from __future__ import annotations

import threading
from collections import deque
from dataclasses import dataclass
from typing import Any

from .util import utc_now


@dataclass(frozen=True, slots=True)
class ObservatoryEvent:
    id: int
    timestamp: str
    kind: str
    level: str
    stage: str | None
    message: str
    data: dict[str, Any]

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "timestamp": self.timestamp,
            "kind": self.kind,
            "level": self.level,
            "stage": self.stage,
            "message": self.message,
            "data": self.data,
        }


class EventBus:
    def __init__(self, *, capacity: int = 1_000) -> None:
        self._events: deque[ObservatoryEvent] = deque(maxlen=capacity)
        self._next_id = 1
        self._condition = threading.Condition()

    def publish(
        self,
        kind: str,
        message: str,
        *,
        level: str = "info",
        stage: str | None = None,
        data: dict[str, Any] | None = None,
        timestamp: str | None = None,
    ) -> ObservatoryEvent:
        if level not in {"info", "success", "warning", "error", "signal"}:
            raise ValueError(f"unsupported event level: {level}")
        with self._condition:
            event = ObservatoryEvent(
                id=self._next_id,
                timestamp=timestamp or utc_now(),
                kind=kind,
                level=level,
                stage=stage,
                message=message,
                data=dict(data or {}),
            )
            self._next_id += 1
            self._events.append(event)
            self._condition.notify_all()
            return event

    def snapshot(self, *, limit: int = 250) -> list[dict[str, Any]]:
        with self._condition:
            return [event.to_dict() for event in list(self._events)[-limit:]]

    def after(self, event_id: int) -> list[ObservatoryEvent]:
        with self._condition:
            return [event for event in self._events if event.id > event_id]

    def wait_after(self, event_id: int, *, timeout: float = 15.0) -> list[ObservatoryEvent]:
        with self._condition:
            available = [event for event in self._events if event.id > event_id]
            if available:
                return available
            self._condition.wait(timeout=timeout)
            return [event for event in self._events if event.id > event_id]

    @property
    def latest_id(self) -> int:
        with self._condition:
            return self._events[-1].id if self._events else 0
