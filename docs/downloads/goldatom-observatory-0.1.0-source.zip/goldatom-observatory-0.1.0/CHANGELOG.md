# Changelog

## 0.1.0 — 2026-09-02

- Added local-first GoldAtom Observatory web interface.
- Added preserved, truth-labelled Bitcoin Core lifecycle replay.
- Added live read-only Bitcoin Core monitor and continuous GoldAtom assay.
- Added isolated regtest lab with fresh atom creation.
- Added structured JSONL lifecycle journal and Server-Sent Events feed.
- Added progressive claim/challenge/work/mint/burial/title state projection.
- Added visible work-hash mutation, challenge mutation, reorganization rejection, and restoration checks.
- Bundled GoldAtom/0 protocol evidence and research documents.
- Added dependency-free packaging, tests, launch scripts, and release validation.
