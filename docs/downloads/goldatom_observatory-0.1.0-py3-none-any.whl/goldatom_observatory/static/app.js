"use strict";

const dom = Object.fromEntries(
  [
    "connectionBadge", "modeLabel", "truthLabel", "runButton", "replayButton", "verifyButton", "proofButton",
    "atomPanel", "atomStatus", "atomDetail", "verdict", "atomId", "atomCoreNumber", "timeline",
    "tipHeight", "tipHash", "chainCanvas", "blockRail", "networkMetric", "chainworkMetric", "latencyMetric",
    "mempoolMetric", "peersMetric", "diskMetric", "workState", "workAttempts", "expectedHashes",
    "workScaleFill", "expectedMarker", "algorithmValue", "workHash", "targetHash", "titleState",
    "titleOutpoint", "scriptType", "titleValue", "titleConfirmations", "burialState", "claimHeight",
    "challengeHeight", "mintHeight", "burialBlocks", "burialNote", "checkCount", "checkGrid",
    "eventTerminal", "clearEvents", "negativeChecks", "documentList", "lastUpdated", "toastStack",
    "proofDrawer", "proofJson", "copyProof"
  ].map((id) => [id, document.getElementById(id)])
);

let currentState = null;
let currentBundleText = "";
let lastEventId = 0;
let clearedThroughId = 0;
let lastTipHeight = null;
let stateFetchInFlight = false;
const renderedEventIds = new Set();

const stageLabels = {
  claim: "CLAIM",
  challenge: "CHALLENGE",
  work: "WORK",
  mint: "MINT",
  burial: "BURIAL",
  title: "TITLE",
  node: "NODE"
};

function setText(element, value, fallback = "—") {
  if (!element) return;
  element.textContent = value === null || value === undefined || value === "" ? fallback : String(value);
}

function fullCopy(element, value) {
  if (!element) return;
  element.dataset.copy = value || "";
}

function shortHash(value, left = 10, right = 8) {
  if (!value) return "—";
  const text = String(value);
  if (text.length <= left + right + 1) return text;
  return `${text.slice(0, left)}…${text.slice(-right)}`;
}

function formatNumber(value) {
  if (value === null || value === undefined || value === "") return "—";
  const number = Number(value);
  return Number.isFinite(number) ? new Intl.NumberFormat("en-US").format(number) : String(value);
}

function formatBytes(value) {
  const number = Number(value);
  if (!Number.isFinite(number) || number < 0) return "—";
  const units = ["B", "KB", "MB", "GB", "TB"];
  let amount = number;
  let index = 0;
  while (amount >= 1024 && index < units.length - 1) {
    amount /= 1024;
    index += 1;
  }
  return `${amount >= 100 ? amount.toFixed(0) : amount.toFixed(1)} ${units[index]}`;
}

function formatSats(value) {
  if (value === null || value === undefined) return "—";
  const sats = Number(value);
  if (!Number.isFinite(sats)) return String(value);
  return `${new Intl.NumberFormat("en-US").format(sats)} sats`;
}

function formatClock(timestamp) {
  if (!timestamp) return "--:--:--";
  const date = new Date(timestamp);
  if (Number.isNaN(date.getTime())) return "--:--:--";
  return date.toLocaleTimeString([], { hour12: false, hour: "2-digit", minute: "2-digit", second: "2-digit" });
}

function formatChainwork(value) {
  if (!value) return "—";
  const text = String(value);
  if (/^[0-9a-f]{64}$/i.test(text)) return `0x…${text.slice(-10)}`;
  try {
    return `2^${Math.log2(Number(BigInt(text))).toFixed(2)}`;
  } catch {
    return shortHash(text, 8, 6);
  }
}

function stateClass(value) {
  if (value === true || value === "complete" || value === "live" || value === "pass") return "is-pass";
  if (value === false || value === "invalid" || value === "fail" || value === "blocked") return "is-fail";
  return "";
}

function renderTimeline(timeline = []) {
  dom.timeline.replaceChildren();
  for (const item of timeline) {
    const step = document.createElement("div");
    step.className = `path-step is-${item.status || "pending"}`;
    step.textContent = item.label || stageLabels[item.id] || item.id;
    step.title = `${step.textContent}: ${item.status || "pending"}`;
    dom.timeline.appendChild(step);
  }
}

function renderBlocks(blocks = []) {
  const priorHeight = lastTipHeight;
  const newestHeight = blocks.length ? Number(blocks[blocks.length - 1].height) : null;
  dom.blockRail.replaceChildren();
  for (const block of blocks.slice(-14)) {
    const cell = document.createElement("button");
    cell.type = "button";
    cell.className = "block";
    cell.dataset.role = block.role || "bitcoin";
    if (block.canonical === false) cell.classList.add("is-noncanonical");
    if (priorHeight !== null && Number(block.height) > priorHeight) cell.classList.add("is-new");
    cell.textContent = block.height;
    const role = String(block.role || "bitcoin").toUpperCase();
    cell.title = `${role} · height ${block.height}\n${block.hash || "hash unavailable"}\n${block.confirmations || 0} confirmation(s)`;
    cell.addEventListener("click", () => copyText(block.hash || String(block.height), `${role} block copied`));
    dom.blockRail.appendChild(cell);
  }
  lastTipHeight = newestHeight;
  drawChain(blocks.slice(-14));
}

function drawChain(blocks) {
  const canvas = dom.chainCanvas;
  if (!canvas) return;
  const rect = canvas.getBoundingClientRect();
  const ratio = Math.max(1, Math.min(window.devicePixelRatio || 1, 2));
  const width = Math.max(100, Math.floor(rect.width));
  const height = Math.max(100, Math.floor(rect.height));
  if (canvas.width !== width * ratio || canvas.height !== height * ratio) {
    canvas.width = width * ratio;
    canvas.height = height * ratio;
  }
  const ctx = canvas.getContext("2d");
  ctx.setTransform(ratio, 0, 0, ratio, 0, 0);
  ctx.clearRect(0, 0, width, height);

  ctx.strokeStyle = "rgba(236,229,210,.08)";
  ctx.lineWidth = 1;
  for (let i = 1; i < 4; i += 1) {
    const y = (height / 4) * i;
    ctx.beginPath();
    ctx.moveTo(0, y + 0.5);
    ctx.lineTo(width, y + 0.5);
    ctx.stroke();
  }
  if (!blocks || blocks.length < 2) return;

  const values = blocks.map((block, index) => {
    try { return Number(BigInt(String(block.chainwork || index + 1))); }
    catch { return index + 1; }
  });
  const min = Math.min(...values);
  const max = Math.max(...values);
  const span = Math.max(1, max - min);
  const points = blocks.map((block, index) => ({
    x: blocks.length === 1 ? width / 2 : (index / (blocks.length - 1)) * width,
    y: height - 22 - ((values[index] - min) / span) * (height - 52),
    block
  }));

  const gradient = ctx.createLinearGradient(0, 0, width, 0);
  gradient.addColorStop(0, "rgba(121,96,42,.45)");
  gradient.addColorStop(1, "rgba(240,202,103,.95)");
  ctx.strokeStyle = gradient;
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  points.forEach((point, index) => index ? ctx.lineTo(point.x, point.y) : ctx.moveTo(point.x, point.y));
  ctx.stroke();

  ctx.lineTo(width, height);
  ctx.lineTo(0, height);
  ctx.closePath();
  const fill = ctx.createLinearGradient(0, 0, 0, height);
  fill.addColorStop(0, "rgba(213,170,62,.12)");
  fill.addColorStop(1, "rgba(213,170,62,0)");
  ctx.fillStyle = fill;
  ctx.fill();

  for (const point of points) {
    const role = point.block.role;
    const color = role === "claim" ? "#7f9fa5" : role === "challenge" ? "#f0ca67" : role === "mint" ? "#e8784e" : role === "burial" ? "#9fbc78" : "#777366";
    ctx.fillStyle = point.block.canonical === false ? "#5b352b" : color;
    ctx.beginPath();
    ctx.arc(point.x, point.y, role === "bitcoin" ? 2.1 : 3.8, 0, Math.PI * 2);
    ctx.fill();
  }
}

function renderWork(work = {}) {
  const attempts = Number(work.attempts || 0);
  const expected = Number(work.expected_hashes || 0);
  setText(dom.workAttempts, formatNumber(attempts), "0");
  setText(dom.expectedHashes, formatNumber(expected));
  setText(dom.algorithmValue, work.algorithm);
  setText(dom.workHash, shortHash(work.hash, 14, 12));
  fullCopy(dom.workHash, work.hash);
  setText(dom.targetHash, shortHash(work.target, 14, 12));
  fullCopy(dom.targetHash, work.target);
  const scaleMax = Math.max(1, attempts, expected * 2);
  const actualPercent = Math.min(100, (attempts / scaleMax) * 100);
  const expectedPercent = Math.min(100, (expected / scaleMax) * 100);
  dom.workScaleFill.style.width = `${actualPercent}%`;
  dom.expectedMarker.style.left = `${expectedPercent}%`;
  setText(dom.workState, String(work.state || "pending").toUpperCase());
  dom.workState.className = `state-chip ${stateClass(work.state)}`;
}

function renderChecks(checks = []) {
  dom.checkGrid.replaceChildren();
  let accepted = 0;
  for (const check of checks) {
    const item = document.createElement("div");
    const status = check.status || "pending";
    item.className = `check is-${status}`;
    const dot = document.createElement("span");
    dot.className = "check-dot";
    const copy = document.createElement("div");
    copy.className = "check-copy";
    const strong = document.createElement("strong");
    strong.textContent = check.label || check.id;
    const small = document.createElement("small");
    small.textContent = check.source || stageLabels[check.stage] || "verifier";
    small.title = check.detail || "";
    copy.append(strong, small);
    const tag = document.createElement("span");
    tag.className = "check-status";
    tag.textContent = String(status).toUpperCase();
    item.append(dot, copy, tag);
    dom.checkGrid.appendChild(item);
    if (status === "pass" || status === "recorded") accepted += 1;
  }
  setText(dom.checkCount, `${accepted} / ${checks.length}`);
}

function renderNegative(checks = {}) {
  const definitions = [
    ["tampered_work_rejected", "MUTATED WORK HASH"],
    ["tampered_challenge_rejected", "MUTATED CHALLENGE"],
    ["challenge_reorg_rejected", "CHALLENGE REORG"],
    ["reconsider_restored_validity", "HISTORY RESTORATION"]
  ];
  dom.negativeChecks.replaceChildren();
  for (const [key, label] of definitions) {
    const value = checks[key];
    const item = document.createElement("div");
    item.className = `negative-item ${value === true ? "is-pass" : "is-pending"}`;
    const name = document.createElement("span");
    name.textContent = label;
    const result = document.createElement("strong");
    result.textContent = value === true ? "REJECT / PASS" : value === false ? "FAIL" : "NOT YET TESTED";
    item.append(name, result);
    dom.negativeChecks.appendChild(item);
  }
}

function renderDocuments(documents = []) {
  if (dom.documentList.dataset.rendered === "1") return;
  dom.documentList.replaceChildren();
  for (const documentInfo of documents) {
    const link = document.createElement("a");
    link.className = "document";
    link.href = documentInfo.url;
    link.target = "_blank";
    link.rel = "noopener";
    const copy = document.createElement("span");
    const strong = document.createElement("strong");
    strong.textContent = documentInfo.title;
    const small = document.createElement("small");
    small.textContent = documentInfo.description;
    copy.append(strong, small);
    const arrow = document.createElement("i");
    arrow.textContent = "↗";
    link.append(copy, arrow);
    dom.documentList.appendChild(link);
  }
  dom.documentList.dataset.rendered = "1";
}

function eventDetail(event) {
  const data = event.data || {};
  if (data.detail) return String(data.detail);
  if (data.height !== undefined) return `height ${data.height}${data.block_hash ? ` · ${shortHash(data.block_hash)}` : ""}`;
  if (data.attempts !== undefined) return `${formatNumber(data.attempts)} attempts${data.work_hash ? ` · ${shortHash(data.work_hash)}` : ""}`;
  if (data.atom_id) return `atom ${shortHash(data.atom_id, 12, 8)}`;
  if (data.error) return String(data.error);
  return "";
}

function appendEvent(event, force = false) {
  const id = Number(event.id || 0);
  if (!force && (id <= clearedThroughId || renderedEventIds.has(id))) return;
  if (id) {
    renderedEventIds.add(id);
    lastEventId = Math.max(lastEventId, id);
  }
  const nearBottom = dom.eventTerminal.scrollHeight - dom.eventTerminal.scrollTop - dom.eventTerminal.clientHeight < 70;
  const row = document.createElement("div");
  row.className = `event is-${event.level || "info"}`;
  const time = document.createElement("time");
  time.textContent = formatClock(event.timestamp);
  const glyph = document.createElement("span");
  glyph.className = "event-glyph";
  glyph.textContent = event.level === "success" ? "+" : event.level === "error" ? "!" : event.level === "warning" ? "△" : event.level === "signal" ? "◆" : "·";
  const copy = document.createElement("div");
  const strong = document.createElement("strong");
  strong.textContent = `${event.stage ? `[${stageLabels[event.stage] || event.stage.toUpperCase()}] ` : ""}${event.message || event.kind}`;
  copy.appendChild(strong);
  const detail = eventDetail(event);
  if (detail) {
    const small = document.createElement("small");
    small.textContent = detail;
    copy.appendChild(small);
  }
  row.append(time, glyph, copy);
  dom.eventTerminal.appendChild(row);
  while (dom.eventTerminal.children.length > 300) dom.eventTerminal.firstElementChild.remove();
  if (nearBottom || force) dom.eventTerminal.scrollTop = dom.eventTerminal.scrollHeight;
}

function renderEvents(events = []) {
  if (!events.length && !dom.eventTerminal.children.length) {
    const empty = document.createElement("div");
    empty.className = "terminal-empty";
    empty.textContent = "Awaiting protocol events…";
    dom.eventTerminal.appendChild(empty);
    return;
  }
  const empty = dom.eventTerminal.querySelector(".terminal-empty");
  if (empty) empty.remove();
  for (const event of events) appendEvent(event);
}

function renderState(state) {
  currentState = state;
  const meta = state.meta || {};
  const node = state.node || {};
  const atom = state.atom || {};
  const title = atom.title || {};
  const burial = atom.burial || {};

  dom.connectionBadge.classList.toggle("is-connected", Boolean(meta.connected));
  dom.connectionBadge.classList.toggle("is-disconnected", !meta.connected);
  setText(dom.modeLabel, meta.mode_label || meta.mode || "UNKNOWN");
  setText(dom.truthLabel, meta.truth_label);

  dom.runButton.classList.toggle("is-hidden", !state.actions?.can_run);
  dom.replayButton.classList.toggle("is-hidden", !state.actions?.can_replay);
  dom.runButton.disabled = Boolean(state.actions?.running);
  setText(dom.runButton, state.actions?.running ? "MINTING…" : "MINT TEST ATOM");

  dom.atomPanel.classList.toggle("is-valid", atom.valid === true);
  dom.atomPanel.classList.toggle("is-invalid", atom.valid === false);
  setText(dom.atomStatus, atom.status);
  setText(dom.atomDetail, atom.status_detail);
  const verdict = atom.valid === true ? "VERIFIED" : atom.valid === false ? "INVALID" : atom.present ? "FORMING" : "UNASSAYED";
  setText(dom.verdict, verdict);
  dom.verdict.className = `verdict ${atom.valid === true ? "is-pass" : atom.valid === false ? "is-fail" : ""}`;
  setText(dom.atomId, atom.atom_id || "—");
  fullCopy(dom.atomId, atom.atom_id);
  setText(dom.atomCoreNumber, atom.atom_id ? atom.atom_id.slice(0, 4).toUpperCase() : "0");
  renderTimeline(state.timeline || []);

  setText(dom.tipHeight, node.height);
  setText(dom.tipHash, shortHash(node.tip_hash, 16, 14));
  fullCopy(dom.tipHash, node.tip_hash);
  setText(dom.networkMetric, node.chain ? String(node.chain).toUpperCase() : "—");
  setText(dom.chainworkMetric, formatChainwork(node.chainwork));
  setText(dom.latencyMetric, node.rpc_latency_ms === null || node.rpc_latency_ms === undefined ? (meta.live ? "—" : "RECORDED") : `${node.rpc_latency_ms} ms`);
  setText(dom.mempoolMetric, node.mempool_txs === null || node.mempool_txs === undefined ? "—" : `${formatNumber(node.mempool_txs)} tx`);
  setText(dom.peersMetric, node.connections === null || node.connections === undefined ? "—" : formatNumber(node.connections));
  setText(dom.diskMetric, formatBytes(node.size_on_disk));
  renderBlocks(state.blocks || []);

  renderWork(atom.work || {});
  setText(dom.titleState, String(title.state || "pending").toUpperCase());
  dom.titleState.className = `state-chip ${stateClass(title.state)}`;
  setText(dom.titleOutpoint, shortHash(title.outpoint, 14, 12));
  fullCopy(dom.titleOutpoint, title.outpoint);
  setText(dom.scriptType, title.script_type || "P2TR / UNKNOWN");
  setText(dom.titleValue, formatSats(title.value_sats));
  setText(dom.titleConfirmations, title.confirmations);

  setText(dom.burialState, String(burial.state || "pending").toUpperCase());
  dom.burialState.className = `state-chip ${stateClass(burial.state)}`;
  setText(dom.claimHeight, atom.claim?.height);
  setText(dom.challengeHeight, atom.challenge?.height);
  setText(dom.mintHeight, atom.mint?.height);
  setText(dom.burialBlocks, burial.blocks === null || burial.blocks === undefined ? "—" : `+${burial.blocks}`);
  const chainwork = burial.chainwork !== null && burial.chainwork !== undefined ? burial.chainwork : "—";
  setText(dom.burialNote, `Burial: ${burial.blocks ?? "—"} block(s) / ${chainwork} chainwork units. Bitcoin security is shared; local work is atom-specific.`);

  renderChecks(state.checks || []);
  renderNegative(state.negative_checks || {});
  renderDocuments(state.documents || []);
  renderEvents(state.events || []);
  setText(dom.lastUpdated, meta.updated_at ? `UPDATED ${formatClock(meta.updated_at)} UTC` : "NO STATE YET");
}

async function refreshState() {
  if (stateFetchInFlight) return;
  stateFetchInFlight = true;
  try {
    const response = await fetch("/api/state", { cache: "no-store" });
    if (!response.ok) throw new Error(`state request failed: ${response.status}`);
    renderState(await response.json());
  } catch (error) {
    dom.connectionBadge.classList.remove("is-connected");
    dom.connectionBadge.classList.add("is-disconnected");
    setText(dom.modeLabel, "SERVER UNREACHABLE");
    toast(error.message || String(error), true);
  } finally {
    stateFetchInFlight = false;
  }
}

async function action(name, payload = {}) {
  const response = await fetch(`/api/action/${encodeURIComponent(name)}`, {
    method: "POST",
    headers: { "Content-Type": "application/json", "X-GoldAtom-Action": "1" },
    body: JSON.stringify(payload)
  });
  const result = await response.json().catch(() => ({ ok: false, error: `HTTP ${response.status}` }));
  if (!response.ok || !result.ok) throw new Error(result.error || `action ${name} failed`);
  await refreshState();
  return result;
}

function toast(message, isError = false) {
  const item = document.createElement("div");
  item.className = `toast${isError ? " is-error" : ""}`;
  item.textContent = message;
  dom.toastStack.appendChild(item);
  window.setTimeout(() => item.remove(), 3200);
}

async function copyText(value, label = "Copied") {
  if (!value) return;
  try {
    await navigator.clipboard.writeText(String(value));
    toast(label);
  } catch {
    const area = document.createElement("textarea");
    area.value = String(value);
    area.style.position = "fixed";
    area.style.opacity = "0";
    document.body.appendChild(area);
    area.select();
    document.execCommand("copy");
    area.remove();
    toast(label);
  }
}

async function openProof() {
  dom.proofDrawer.classList.add("is-open");
  dom.proofDrawer.setAttribute("aria-hidden", "false");
  dom.proofJson.textContent = "Loading proof bundle…";
  try {
    const response = await fetch("/api/bundle", { cache: "no-store" });
    if (!response.ok) throw new Error((await response.json()).error || "No bundle loaded");
    const bundle = await response.json();
    currentBundleText = JSON.stringify(bundle, null, 2);
    dom.proofJson.textContent = currentBundleText;
  } catch (error) {
    currentBundleText = "";
    dom.proofJson.textContent = error.message || String(error);
  }
}

function closeProof() {
  dom.proofDrawer.classList.remove("is-open");
  dom.proofDrawer.setAttribute("aria-hidden", "true");
}

function connectEvents() {
  const stream = new EventSource(`/api/events?since=${lastEventId}`);
  stream.addEventListener("observatory", (message) => {
    try {
      const event = JSON.parse(message.data);
      const empty = dom.eventTerminal.querySelector(".terminal-empty");
      if (empty) empty.remove();
      appendEvent(event, true);
      window.setTimeout(refreshState, 50);
    } catch (error) {
      console.error("invalid event frame", error);
    }
  });
  stream.onerror = () => {
    // EventSource reconnects automatically. The state poll remains the fallback.
  };
}

for (const element of document.querySelectorAll(".copyable")) {
  element.addEventListener("click", () => copyText(element.dataset.copy, "Value copied"));
}

dom.runButton.addEventListener("click", async () => {
  try {
    await action("run");
    toast("Fresh regtest lifecycle started");
  } catch (error) { toast(error.message || String(error), true); }
});

dom.replayButton.addEventListener("click", async () => {
  try {
    clearedThroughId = lastEventId;
    renderedEventIds.clear();
    dom.eventTerminal.replaceChildren();
    await action("replay");
    toast("Replay restarted");
  } catch (error) { toast(error.message || String(error), true); }
});

dom.verifyButton.addEventListener("click", async () => {
  dom.verifyButton.disabled = true;
  setText(dom.verifyButton, "ASSAYING…");
  try {
    const result = await action("verify");
    toast(result.result?.valid === false ? "Assay failed" : "Assay completed", result.result?.valid === false);
  } catch (error) { toast(error.message || String(error), true); }
  finally { dom.verifyButton.disabled = false; setText(dom.verifyButton, "REASSAY"); }
});

dom.proofButton.addEventListener("click", openProof);
dom.copyProof.addEventListener("click", () => copyText(currentBundleText, "Full proof copied"));
for (const closer of document.querySelectorAll("[data-close-drawer]")) closer.addEventListener("click", closeProof);

dom.clearEvents.addEventListener("click", () => {
  clearedThroughId = lastEventId;
  renderedEventIds.clear();
  dom.eventTerminal.replaceChildren();
  const empty = document.createElement("div");
  empty.className = "terminal-empty";
  empty.textContent = "View cleared. New events will continue streaming.";
  dom.eventTerminal.appendChild(empty);
});

document.addEventListener("keydown", (event) => {
  if (event.key === "Escape") closeProof();
  if (event.target instanceof HTMLInputElement || event.target instanceof HTMLTextAreaElement) return;
  if (event.key.toLowerCase() === "j") openProof();
  if (event.key.toLowerCase() === "v") dom.verifyButton.click();
  if (event.key.toLowerCase() === "r" && !dom.replayButton.classList.contains("is-hidden")) dom.replayButton.click();
});

window.addEventListener("resize", () => currentState && drawChain((currentState.blocks || []).slice(-14)));

refreshState();
connectEvents();
window.setInterval(refreshState, 1800);
