"""Read-only Bitcoin Core monitor and live GoldAtom verifier."""

from __future__ import annotations

import copy
import threading
import time
from decimal import Decimal
from pathlib import Path
from typing import Any, Callable

from goldatom.core_rpc import CoreBitcoinView, JsonRpcClient
from goldatom.models import GoldAtomBundle, Outpoint
from goldatom.verify import VerificationError, verify_bundle

from .diagnostics import (
    checks_from_error,
    checks_from_report,
    offline_checks,
    offline_facts,
    terminal_outpoint,
)
from .events import EventBus
from .evidence import Evidence
from .util import utc_now


class CoreMonitor:
    """Poll a fully validating Core node and continuously reassay one proof bundle.

    The monitor only calls read-only RPC methods. Lifecycle creation is handled by the
    explicitly separate regtest lab runner.
    """

    mode = "core"

    def __init__(
        self,
        bus: EventBus,
        *,
        rpc_url: str,
        rpc_user: str | None = None,
        rpc_password: str | None = None,
        cookie_file: str | Path | None = None,
        bundle_path: str | Path | None = None,
        poll_interval: float = 1.25,
        auto_start: bool = True,
    ) -> None:
        self.bus = bus
        self.rpc = JsonRpcClient(
            rpc_url,
            username=rpc_user,
            password=rpc_password,
            cookie_file=cookie_file,
            timeout=max(3.0, poll_interval * 2.0),
        )
        self.view = CoreBitcoinView(self.rpc)
        self.bundle_path = Path(bundle_path).expanduser().resolve() if bundle_path else None
        self.poll_interval = max(0.4, float(poll_interval))
        self._lock = threading.RLock()
        self._stop = threading.Event()
        self._wake = threading.Event()
        self._thread: threading.Thread | None = None
        self._bundle: GoldAtomBundle | None = None
        self._bundle_mtime_ns: int | None = None
        self._header_cache: dict[str, dict[str, Any]] = {}
        self._last_connected: bool | None = None
        self._last_tip_hash: str | None = None
        self._last_valid: bool | None = None
        self._last_atom_id: str | None = None
        self._last_title: str | None = None
        self._action_state_provider: Callable[[], dict[str, Any]] | None = None
        self._state = self._empty_state()
        if auto_start:
            self.start()

    def _empty_state(self) -> dict[str, Any]:
        return {
            "meta": {
                "name": "GOLDATOM OBSERVATORY",
                "version": "0.1.0",
                "mode": "core",
                "mode_label": "LIVE BITCOIN CORE",
                "connected": False,
                "live": True,
                "truth_label": "Direct read-only assay against the configured Bitcoin Core node.",
                "started_at": utc_now(),
                "updated_at": utc_now(),
                "poll_interval": self.poll_interval,
            },
            "node": {
                "chain": None,
                "height": None,
                "headers": None,
                "tip_hash": None,
                "chainwork": None,
                "difficulty": None,
                "verification_progress": None,
                "connections": None,
                "mempool_txs": None,
                "size_on_disk": None,
                "rpc_latency_ms": None,
                "subversion": None,
                "warning": None,
                "error": None,
            },
            "atom": {
                "present": False,
                "valid": None,
                "status": "WAITING FOR NODE",
                "status_detail": "No current Core assay is available.",
                "profile": None,
                "atom_id": None,
                "claim": {},
                "challenge": {},
                "work": {},
                "mint": {},
                "burial": {},
                "title": {},
                "error": None,
            },
            "timeline": self._timeline(None, False),
            "checks": [],
            "blocks": [],
            "negative_checks": {},
            "actions": {
                "can_replay": False,
                "can_verify": True,
                "can_run": False,
                "running": False,
            },
            "documents": Evidence.documents(),
        }

    @staticmethod
    def _timeline(valid: bool | None, has_bundle: bool) -> list[dict[str, str]]:
        labels = (
            ("claim", "CLAIM"),
            ("challenge", "CHALLENGE"),
            ("work", "LOCAL WORK"),
            ("mint", "MINT"),
            ("burial", "BURIAL"),
            ("title", "TITLE"),
        )
        if not has_bundle:
            return [{"id": stage, "label": label, "status": "pending"} for stage, label in labels]
        status = "complete" if valid else "unknown"
        return [{"id": stage, "label": label, "status": status} for stage, label in labels]

    def set_action_state_provider(self, provider: Callable[[], dict[str, Any]]) -> None:
        self._action_state_provider = provider

    def set_bundle_path(self, path: str | Path | None) -> None:
        with self._lock:
            self.bundle_path = Path(path).expanduser().resolve() if path else None
            self._bundle = None
            self._bundle_mtime_ns = None
            self._wake.set()

    def _load_bundle(self) -> GoldAtomBundle | None:
        path = self.bundle_path
        if path is None or not path.exists():
            return None
        stat = path.stat()
        if self._bundle is None or self._bundle_mtime_ns != stat.st_mtime_ns:
            loaded = GoldAtomBundle.read(path)
            self._bundle = loaded
            self._bundle_mtime_ns = stat.st_mtime_ns
            self.bus.publish(
                "bundle.loaded",
                f"Loaded proof bundle {path.name}.",
                level="signal",
                data={"path": str(path)},
            )
        return self._bundle

    def _header(self, block_hash: str) -> dict[str, Any]:
        cached = self._header_cache.get(block_hash)
        if cached is not None:
            return cached
        result = self.rpc.call("getblockheader", block_hash, True)
        clean = {
            "height": int(result["height"]),
            "hash": str(result["hash"]),
            "confirmations": int(result["confirmations"]),
            "chainwork": str(int(str(result["chainwork"]), 16)),
            "time": int(result["time"]),
        }
        self._header_cache[block_hash] = clean
        if len(self._header_cache) > 256:
            self._header_cache = dict(list(self._header_cache.items())[-128:])
        return clean

    def _recent_blocks(self, tip_height: int, bundle: GoldAtomBundle | None) -> list[dict[str, Any]]:
        roles: dict[str, str] = {}
        if bundle is not None:
            roles = {
                bundle.claim.block_hash: "claim",
                bundle.work.challenge_block_hash: "challenge",
                bundle.mint.block_hash: "mint",
            }
            for transition in bundle.transfers:
                roles[transition.block_hash] = "transfer"
        result: list[dict[str, Any]] = []
        start = max(0, tip_height - 13)
        for height in range(start, tip_height + 1):
            block_hash = str(self.rpc.call("getblockhash", height))
            header = self._header(block_hash)
            role = roles.get(block_hash, "bitcoin")
            if bundle is not None and height > bundle.mint.height and role == "bitcoin":
                role = "burial"
            result.append(
                {
                    **header,
                    "role": role,
                    "canonical": header["confirmations"] > 0,
                    "recorded": False,
                }
            )
        return result

    @staticmethod
    def _sats(value: Any) -> int:
        return int((value if isinstance(value, Decimal) else Decimal(str(value))) * Decimal(100_000_000))

    def _bundle_projection(
        self,
        bundle: GoldAtomBundle,
        *,
        report: Any | None,
        verify_error: Exception | None,
        title_utxo: dict[str, Any] | None,
    ) -> dict[str, Any]:
        facts = offline_facts(bundle)
        atom_id = report.atom_id if report is not None else facts["atom_id"]
        title = terminal_outpoint(bundle)
        valid = report is not None
        if report is not None:
            status = "VALID GOLDATOM / 0"
            detail = "Every normative gate verifies against the active Bitcoin Core chain."
            checks = checks_from_report(report)
            burial_blocks = report.burial_blocks
            burial_chainwork = str(report.burial_chainwork)
            title_outpoint = report.current_title_outpoint
        else:
            status = "ASSAY FAILED" if verify_error is not None else "VERIFYING"
            detail = str(verify_error) if verify_error is not None else "Assay is in progress."
            if isinstance(verify_error, VerificationError):
                checks = checks_from_error(verify_error)
            else:
                checks = offline_checks(bundle)
            burial_blocks = 0
            burial_chainwork = "0"
            title_outpoint = title

        script_type = None
        address = None
        title_confirmations = 0
        value_sats = None
        unspent: bool | None = False if valid and title_utxo is None else None
        if title_utxo is not None:
            script = title_utxo.get("scriptPubKey") or {}
            script_type = script.get("type")
            address = script.get("address")
            title_confirmations = int(title_utxo.get("confirmations", 0))
            value_sats = self._sats(title_utxo.get("value", 0))
            unspent = True

        return {
            "atom": {
                "present": True,
                "valid": valid,
                "status": status,
                "status_detail": detail,
                "profile": bundle.profile,
                "atom_id": atom_id,
                "claim": {
                    "height": bundle.claim.height,
                    "outpoint": str(bundle.claim.outpoint),
                    "block_hash": bundle.claim.block_hash,
                    "commitment": bundle.claim.commitment_hex,
                    "state": "complete" if valid else "unknown",
                },
                "challenge": {
                    "height": bundle.work.challenge_height,
                    "block_hash": bundle.work.challenge_block_hash,
                    "digest": bundle.work.challenge_digest_hex,
                    "state": "complete" if valid else "unknown",
                },
                "work": {
                    "algorithm": bundle.claim.algorithm,
                    "target": bundle.claim.target_hex,
                    "hash": bundle.work.work_hash_hex,
                    "expected_hashes": facts["expected_hashes"],
                    "expected_work_log2": facts["expected_work_log2"],
                    "attempts": facts["attempts"],
                    "final_attempts": facts["attempts"],
                    "attempts_source": "derived from version-zero sequential counters",
                    "state": "complete" if valid else "unknown",
                },
                "mint": {
                    "height": bundle.mint.height,
                    "txid": bundle.mint.txid,
                    "block_hash": bundle.mint.block_hash,
                    "commitment": bundle.mint.commitment_hex,
                    "state": "complete" if valid else "unknown",
                },
                "burial": {
                    "blocks": burial_blocks,
                    "chainwork": burial_chainwork,
                    "required_blocks": 1,
                    "state": "complete" if valid else "unknown",
                },
                "title": {
                    "outpoint": str(title_outpoint),
                    "script_hex": (
                        bundle.transfers[-1].successor_script_hex
                        if bundle.transfers
                        else bundle.mint.title_script_hex
                    ),
                    "script_type": script_type,
                    "address": address,
                    "value_sats": value_sats,
                    "confirmations": title_confirmations,
                    "unspent": unspent,
                    "state": "live" if valid and unspent else "unknown",
                },
                "error": (
                    {"type": type(verify_error).__name__, "message": str(verify_error)}
                    if verify_error is not None
                    else None
                ),
            },
            "checks": checks,
            "timeline": self._timeline(valid, True),
        }

    def poll(self) -> None:
        start = time.perf_counter()
        try:
            bundle = self._load_bundle()
            chain = self.rpc.call("getblockchaininfo")
            network = self.rpc.call("getnetworkinfo")
            try:
                mempool = self.rpc.call("getmempoolinfo")
            except Exception:
                mempool = {}
            latency_ms = round((time.perf_counter() - start) * 1_000, 2)
            connected = True

            report = None
            verify_error: Exception | None = None
            title_utxo = None
            if bundle is not None:
                try:
                    report = verify_bundle(bundle, self.view)
                except Exception as exc:
                    verify_error = exc
                terminal = terminal_outpoint(bundle)
                try:
                    title_utxo = self.rpc.call("gettxout", terminal.txid, terminal.vout, True)
                except Exception:
                    title_utxo = None

            tip_height = int(chain["blocks"])
            blocks = self._recent_blocks(tip_height, bundle)
            node_state = {
                "chain": str(chain["chain"]),
                "height": tip_height,
                "headers": int(chain["headers"]),
                "tip_hash": str(chain["bestblockhash"]),
                "chainwork": str(chain["chainwork"]),
                "difficulty": str(chain.get("difficulty")),
                "verification_progress": float(chain.get("verificationprogress", 0)),
                "connections": int(network.get("connections", 0)),
                "mempool_txs": int(mempool.get("size", 0)),
                "size_on_disk": int(chain.get("size_on_disk", 0)),
                "rpc_latency_ms": latency_ms,
                "subversion": str(network.get("subversion", "Bitcoin Core")),
                "warning": chain.get("warnings") or network.get("warnings") or None,
                "error": None,
            }
            with self._lock:
                state = self._empty_state()
                state["meta"].update(
                    {
                        "connected": True,
                        "updated_at": utc_now(),
                        "live": True,
                        "mode_label": f"LIVE CORE · {node_state['chain'].upper()}",
                    }
                )
                state["node"] = node_state
                state["blocks"] = blocks
                if bundle is not None:
                    state.update(
                        self._bundle_projection(
                            bundle,
                            report=report,
                            verify_error=verify_error,
                            title_utxo=title_utxo,
                        )
                    )
                else:
                    state["atom"].update(
                        {
                            "status": "WAITING FOR PROOF BUNDLE",
                            "status_detail": (
                                f"Watching {self.bundle_path}" if self.bundle_path else "No bundle path configured."
                            ),
                        }
                    )
                if self._action_state_provider is not None:
                    state["actions"].update(self._action_state_provider())
                state["events"] = self.bus.snapshot()
                self._state = state

            current_tip = node_state["tip_hash"]
            current_valid = report is not None if bundle is not None else None
            current_atom_id = report.atom_id if report is not None else (
                offline_facts(bundle)["atom_id"] if bundle is not None else None
            )
            current_title = str(report.current_title_outpoint) if report is not None else None

            if self._last_connected is not True:
                self.bus.publish(
                    "node.connected",
                    f"Connected to Bitcoin Core on {node_state['chain']} at height {tip_height}.",
                    level="success",
                    data={"height": tip_height, "tip_hash": current_tip},
                )
            if self._last_tip_hash is not None and current_tip != self._last_tip_hash:
                self.bus.publish(
                    "block.connected",
                    f"Best chain advanced to height {tip_height}.",
                    level="info",
                    data={"height": tip_height, "tip_hash": current_tip},
                )
            if bundle is not None and current_atom_id != self._last_atom_id:
                self.bus.publish(
                    "atom.detected",
                    f"GoldAtom proof {current_atom_id[:12]}… entered the observatory.",
                    level="signal",
                    data={"atom_id": current_atom_id, "bundle": str(self.bundle_path)},
                )
            if bundle is not None and current_valid != self._last_valid:
                if current_valid:
                    self.bus.publish(
                        "verification.pass",
                        "GoldAtom verifier accepted the proof against the active chain.",
                        level="success",
                        stage="title",
                        data={"atom_id": current_atom_id},
                    )
                elif verify_error is not None:
                    self.bus.publish(
                        "verification.fail",
                        f"GoldAtom assay failed: {verify_error}",
                        level="error",
                        stage="title",
                        data={"error": str(verify_error)},
                    )
            if current_title is not None and current_title != self._last_title:
                self.bus.publish(
                    "title.live",
                    f"Terminal title seal is live at {current_title}.",
                    level="success",
                    stage="title",
                    data={"outpoint": current_title},
                )

            self._last_connected = connected
            self._last_tip_hash = current_tip
            self._last_valid = current_valid
            self._last_atom_id = current_atom_id
            self._last_title = current_title
        except Exception as exc:
            with self._lock:
                state = copy.deepcopy(self._state)
                state["meta"].update({"connected": False, "updated_at": utc_now()})
                state["node"]["error"] = str(exc)
                state["atom"].update(
                    {
                        "status": "CORE DISCONNECTED",
                        "status_detail": str(exc),
                        "valid": None,
                    }
                )
                if self._action_state_provider is not None:
                    state["actions"].update(self._action_state_provider())
                state["events"] = self.bus.snapshot()
                self._state = state
            if self._last_connected is not False:
                self.bus.publish(
                    "node.disconnected",
                    f"Bitcoin Core connection failed: {exc}",
                    level="error",
                    data={"error": str(exc)},
                )
            self._last_connected = False

    def start(self) -> None:
        with self._lock:
            if self._thread and self._thread.is_alive():
                return
            self._thread = threading.Thread(target=self._run, name="goldatom-core-monitor", daemon=True)
            self._thread.start()

    def _run(self) -> None:
        while not self._stop.is_set():
            self.poll()
            self._wake.wait(self.poll_interval)
            self._wake.clear()

    def stop(self) -> None:
        self._stop.set()
        self._wake.set()
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=3.0)

    def force_verify(self) -> dict[str, Any]:
        self.poll()
        state = self.get_state()
        return {
            "connected": state["meta"]["connected"],
            "valid": state["atom"].get("valid"),
            "error": state["atom"].get("error") or state["node"].get("error"),
        }

    def get_state(self) -> dict[str, Any]:
        with self._lock:
            state = copy.deepcopy(self._state)
            if self._action_state_provider is not None:
                state["actions"].update(self._action_state_provider())
            state["events"] = self.bus.snapshot()
            return state

    def get_bundle_dict(self) -> dict[str, Any] | None:
        with self._lock:
            return self._bundle.to_dict() if self._bundle is not None else None
