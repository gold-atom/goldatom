# GoldAtom Observatory 0.1.0 — Build and Validation Transcript

Date: 2026-09-02 UTC  
Author: Jcb  
Protocol displayed: GoldAtom/0 Proof-Buried Work

## Request translated into an executable target

The requested site needed to show the GoldAtom lifecycle **while it was actually occurring**, rather than animate a fictionalized blockchain diagram. The implementation therefore separates three modes of evidence:

1. **Recorded replay** — reconstructs the already-preserved Bitcoin Core validation and labels every chain-dependent fact as recorded.
2. **Fresh live laboratory** — starts an isolated Bitcoin Core `regtest` node, constructs a new atom, streams structured lifecycle events, attacks the result, and continuously reassays it.
3. **Read-only Core attachment** — watches an operator-supplied Core node and proof bundle without creating transactions or blocks.

The browser is only a projection surface. Protocol-local calculations are performed by the GoldAtom library; active-chain facts are obtained from Bitcoin Core; the two classes are not silently conflated.

## Delivered architecture

```text
browser instrument panel
  ├─ coherent state snapshots over /api/state
  ├─ monotonic Server-Sent Events over /api/events
  ├─ raw portable proof over /api/bundle
  └─ guarded local actions
          │
          ▼
stdlib Python HTTP server
  ├─ ReplayMonitor
  ├─ CoreMonitor (read-only RPC)
  └─ LiveLab
       ├─ fresh private regtest datadir
       ├─ P2P listening disabled
       ├─ private RPC cookie
       ├─ observed claim→challenge→work→mint→burial lifecycle
       └─ append-only JSONL journal
```

No front-end build system, package registry, CDN, analytics service, web font, or third-party JavaScript is required. That choice reduces the trusted surface and makes the release runnable from an extracted directory with Python 3.11 or newer.

## What the live panel exposes

- Core connection, network, height, best block, chainwork, peers, mempool, RPC latency, and disk use.
- Claim transaction, commitment, seal outpoint, confirmation block, and height.
- Future challenge height, canonical challenge block, and derived digest.
- Every observed local-work attempt summary, fixed target, expected hashes, nonce, and winning hash.
- Mint transaction, single-use claim consumption, title output, and confirmation block.
- Post-mint burial blocks and chainwork.
- Current title UTXO, value, script type, and confirmations.
- Sixteen verifier gates with source labels.
- Work-hash mutation, challenge mutation, challenge-block invalidation, and canonical restoration.
- Structured transcript, protocol documents, proof JSON, and evidence downloads.

## Executed live laboratory run

The Observatory action API started a fresh lifecycle against a private Bitcoin Core regtest node. The resulting object was:

```text
Atom ID:                  6444e4843b5c8c4af3bdfb2a763e7e3fd41542fd890a4572d4c9c89057fe109d
Profile:                  goldatom-regtest-v0
Claim height:             102
Challenge height:         105
Mint height:              106
Assay tip:                107
Local work attempts:      15
Expected local hashes:    16
Bitcoin burial blocks:    1
Bitcoin burial chainwork: 2
Current title:            c2d97bf3c716154e55d9e096fb85827d8c92f3561dd8ffb7be690865148bb8ae:0
Title confirmations:      2
Verifier gates:           16 / 16 pass
Lifecycle exit code:      0
```

The site observed this exact sequence:

```text
Core start
  → 101 regtest maturity blocks
  → claim broadcast
  → claim confirmation at 102
  → future blocks 103–105
  → challenge fixed at 105
  → exclusive local proof after 15 attempts
  → mint broadcast
  → title confirmation at 106
  → burial at 107
  → portable proof emission
  → independent 16-gate assay
  → adversarial tests
  → continuous reassay
```

The complete event-by-event record is preserved in `GOLDATOM-OBSERVATORY-0.1.0-LIVE-TRANSCRIPT.md` and `validation/observatory-live-lab/events.jsonl`.

## Adversarial results

| Deliberate attack | Verifier behavior | Result |
|---|---|---|
| Mutated work hash | Rejected at `BAD_WORK_HASH` | Pass |
| Mutated challenge digest | Rejected at `BAD_CHALLENGE` | Pass |
| Challenge block removed from the active chain | Existing atom ceased to verify | Pass |
| Same block reconsidered and history restored | Unchanged atom verified again | Pass |

The reorganization test is important because it demonstrates that the UI is not merely presenting a cached green verdict: validity follows the active Bitcoin history to which the proof commits.

## Node provenance

```text
Bitcoin Core daemon version v31.99.0-031175197f1b bitcoind
Binary SHA-256: 8e3afd78738ebc6d59787fc232c4f0025b6a3dd1e2c59cee4fd1b5ed1ba3dba4
Network: regtest
P2P listening: disabled
RPC authentication: private cookie
```

This is a genuine Bitcoin Core execution, but the available binary was a pre-release build rather than a signed production release. The dashboard and validation documents display that caveat explicitly.

## Automated and packaging validation

Final source-tree checks:

```text
46 automated tests: PASS
Python compileall:  PASS
JavaScript syntax:  PASS
```

The tests cover inherited protocol, RPC, and economic simulations plus Observatory event sequencing, journal projection, replay truth labelling, HTTP security headers, action guards, HEAD behavior, loopback binding policy, package evidence, runtime state persistence, and private lab allocation.

The wheel was installed into a clean virtual environment with no runtime dependencies. Replay mode served successfully from the installed package. A separate installed-wheel live lab produced another valid atom with 16/16 checks and all four adversarial signals.

## Security boundary

- The server binds to `127.0.0.1` by default.
- Public binding is refused unless an explicit unsafe override is supplied.
- Browser actions require `X-GoldAtom-Action: 1` as an accidental-request guard.
- RPC credentials remain server-side.
- Live construction is hard-restricted to `regtest`.
- The sanitized evidence bundle excludes wallets, cookies, private keys, chainstate, and the private Bitcoin datadir.

This is a local research instrument, not an authenticated public service. Internet exposure requires an independently hardened reverse proxy, authenticated TLS, and isolated node policy.

## Scientific boundary

The release demonstrates a coherent, observable GoldAtom/0 object lifecycle. It does **not** establish GoldAtom/1 monetary issuance, mainnet safety, market value, fair distribution, physical energy provenance, or immunity from source-miner manipulation. Those remain separate research questions rather than claims smuggled into the interface.
