#!/bin/sh
set -eu
cd "$(dirname "$0")"
PYTHON_BIN="${PYTHON_BIN:-python3}"
MODE="${1:-replay}"
case "$MODE" in
  replay)
    shift || true
    exec "$PYTHON_BIN" -m goldatom_observatory serve "$@"
    ;;
  lab)
    shift || true
    BITCOIND_PATH="${1:-${BITCOIND:-}}"
    if [ -z "$BITCOIND_PATH" ]; then
      BITCOIND_PATH="$(command -v bitcoind 2>/dev/null || true)"
    else
      shift || true
    fi
    if [ -z "$BITCOIND_PATH" ]; then
      printf '%s\n' "No bitcoind found. Supply it as the second argument or set BITCOIND." >&2
      printf '%s\n' "Example: ./start-observatory.sh lab /absolute/path/to/bitcoind" >&2
      exit 2
    fi
    exec "$PYTHON_BIN" -m goldatom_observatory lab --bitcoind "$BITCOIND_PATH" "$@"
    ;;
  *)
    printf '%s\n' "Usage: $0 replay [options] | lab [/path/to/bitcoind] [options]" >&2
    exit 2
    ;;
esac
