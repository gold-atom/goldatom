#!/usr/bin/env python3
"""Compatibility wrapper for the packaged instrumented regtest lifecycle."""

from goldatom_observatory.observed_regtest_demo import main

if __name__ == "__main__":
    raise SystemExit(main())
