"""Isolated Bitcoin Core regtest lab used by the live Observatory mode."""

from __future__ import annotations

import hashlib
import os
import shutil
import socket
import secrets
import subprocess
import sys
import threading
import time
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, Callable

from goldatom.core_rpc import JsonRpcClient

from .events import EventBus


ROOT = Path(__file__).resolve().parents[1]
KNOWN_BINARIES = (
    Path("/opt/homebrew/bin/bitcoind"),
    Path("/usr/local/bin/bitcoind"),
    Path("/usr/bin/bitcoind"),
)


def discover_bitcoind(explicit: str | Path | None = None) -> Path | None:
    candidates: list[Path] = []
    if explicit:
        candidates.append(Path(explicit).expanduser())
    env = os.environ.get("BITCOIND")
    if env:
        candidates.append(Path(env).expanduser())
    in_path = shutil.which("bitcoind")
    if in_path:
        candidates.append(Path(in_path))
    candidates.extend(KNOWN_BINARIES)
    for candidate in candidates:
        if candidate.is_file() and os.access(candidate, os.X_OK):
            return candidate.resolve()
    return None


def free_tcp_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.bind(("127.0.0.1", 0))
        return int(sock.getsockname()[1])


class LiveLab:
    """Own an isolated regtest node and run instrumented GoldAtom lifecycles."""

    def __init__(
        self,
        bus: EventBus,
        *,
        bitcoind: str | Path,
        run_root: str | Path,
        visual_delay: float = 0.55,
    ) -> None:
        self.bus = bus
        self.bitcoind = Path(bitcoind).expanduser().resolve()
        if not self.bitcoind.is_file() or not os.access(self.bitcoind, os.X_OK):
            raise FileNotFoundError(f"executable bitcoind not found: {self.bitcoind}")
        timestamp = datetime.now(UTC).strftime("%Y%m%dT%H%M%SZ")
        run_id = f"lab-{timestamp}-{os.getpid()}-{secrets.token_hex(3)}"
        self.run_dir = Path(run_root).expanduser().resolve() / run_id
        self.run_dir.mkdir(parents=True, exist_ok=False)
        self.datadir = self.run_dir / "node"
        self.datadir.mkdir()
        self.journal_path = self.run_dir / "events.jsonl"
        self.visual_delay = max(0.0, float(visual_delay))
        self.rpc_port = free_tcp_port()
        self.rpc_url = f"http://127.0.0.1:{self.rpc_port}"
        self.cookie_file = self.datadir / "regtest" / ".cookie"
        self.node_stdout_path = self.run_dir / "bitcoind.stdout.log"
        self.node_stderr_path = self.run_dir / "bitcoind.stderr.log"
        self._node_stdout = None
        self._node_stderr = None
        self._process: subprocess.Popen[str] | None = None
        self._lifecycle: subprocess.Popen[str] | None = None
        self._lifecycle_thread: threading.Thread | None = None
        self._lock = threading.RLock()
        self._run_number = 0
        self._current_bundle: Path | None = None
        self._last_exit_code: int | None = None
        self._on_bundle: Callable[[Path], None] | None = None

    def start_node(self) -> None:
        with self._lock:
            if self._process and self._process.poll() is None:
                return
            self._node_stdout = self.node_stdout_path.open("a", encoding="utf-8")
            self._node_stderr = self.node_stderr_path.open("a", encoding="utf-8")
            command = [
                str(self.bitcoind),
                "-regtest",
                f"-datadir={self.datadir}",
                "-server=1",
                "-txindex=1",
                "-fallbackfee=0.0002",
                f"-rpcport={self.rpc_port}",
                "-listen=0",
                "-printtoconsole=1",
            ]
            self._process = subprocess.Popen(
                command,
                cwd=ROOT,
                text=True,
                stdout=self._node_stdout,
                stderr=self._node_stderr,
            )
        self.bus.publish(
            "lab.node.starting",
            "Starting isolated Bitcoin Core regtest node.",
            level="signal",
            data={"run_dir": str(self.run_dir), "rpc_port": self.rpc_port},
        )
        self._wait_for_rpc()
        version = subprocess.run(
            [str(self.bitcoind), "--version"],
            text=True,
            capture_output=True,
            check=False,
        ).stdout.splitlines()
        binary_hash = hashlib.sha256(self.bitcoind.read_bytes()).hexdigest()
        (self.run_dir / "bitcoind-version.txt").write_text("\n".join(version) + "\n", encoding="utf-8")
        (self.run_dir / "bitcoind.sha256").write_text(f"{binary_hash}  {self.bitcoind.name}\n", encoding="utf-8")
        self.bus.publish(
            "lab.node.ready",
            f"Bitcoin Core ready on private RPC port {self.rpc_port}.",
            level="success",
            data={
                "version": version[0] if version else "unknown",
                "binary_sha256": binary_hash,
            },
        )

    def _wait_for_rpc(self) -> None:
        deadline = time.monotonic() + 30.0
        last_error: Exception | None = None
        while time.monotonic() < deadline:
            process = self._process
            if process is None or process.poll() is not None:
                raise RuntimeError(
                    f"bitcoind exited during startup with status {process.returncode if process else 'unknown'}"
                )
            if self.cookie_file.exists():
                try:
                    rpc = JsonRpcClient(self.rpc_url, cookie_file=self.cookie_file, timeout=3.0)
                    rpc.call("getblockchaininfo")
                    return
                except Exception as exc:
                    last_error = exc
            time.sleep(0.05)
        raise RuntimeError(f"Bitcoin Core RPC did not become ready: {last_error}")

    def attach_bundle_callback(self, callback: Callable[[Path], None]) -> None:
        self._on_bundle = callback

    def start_lifecycle(self) -> bool:
        with self._lock:
            if self._lifecycle and self._lifecycle.poll() is None:
                return False
            self._run_number += 1
            self._last_exit_code = None
            output = self.run_dir / f"atom-{self._run_number:04d}.goldatom.json"
            self._current_bundle = output
            if self._on_bundle is not None:
                self._on_bundle(output)
            command = [
                sys.executable,
                "-m",
                "goldatom_observatory.observed_regtest_demo",
                "--rpc-url",
                self.rpc_url,
                "--cookie-file",
                str(self.cookie_file),
                "--wallet",
                "goldatom-observatory",
                "--output",
                str(output),
                "--journal",
                str(self.journal_path),
                "--visual-delay",
                str(self.visual_delay),
            ]
            stdout_path = self.run_dir / f"lifecycle-{self._run_number:04d}.stdout.log"
            stderr_path = self.run_dir / f"lifecycle-{self._run_number:04d}.stderr.log"
            stdout_handle = stdout_path.open("w", encoding="utf-8")
            stderr_handle = stderr_path.open("w", encoding="utf-8")
            self._lifecycle = subprocess.Popen(
                command,
                cwd=ROOT,
                text=True,
                stdout=stdout_handle,
                stderr=stderr_handle,
            )
            process = self._lifecycle
            run_number = self._run_number

        self.bus.publish(
            "lab.lifecycle.spawned",
            f"Spawned fresh GoldAtom lifecycle #{run_number}.",
            level="signal",
            data={"output": str(output), "run_number": run_number},
        )

        def wait() -> None:
            code = process.wait()
            stdout_handle.close()
            stderr_handle.close()
            with self._lock:
                self._last_exit_code = code
            if code == 0:
                self.bus.publish(
                    "lab.lifecycle.exit",
                    f"Lifecycle #{run_number} completed successfully.",
                    level="success",
                    data={"bundle": str(output), "status": code},
                )
            else:
                detail = stderr_path.read_text(encoding="utf-8", errors="replace")[-1_500:]
                self.bus.publish(
                    "lab.lifecycle.exit",
                    f"Lifecycle #{run_number} exited with status {code}.",
                    level="error",
                    data={"stderr": detail, "status": code},
                )

        self._lifecycle_thread = threading.Thread(target=wait, name="goldatom-lifecycle", daemon=True)
        self._lifecycle_thread.start()
        return True

    def action_state(self) -> dict[str, Any]:
        with self._lock:
            running = self._lifecycle is not None and self._lifecycle.poll() is None
            return {
                "can_run": True,
                "running": running,
                "run_number": self._run_number,
                "last_exit_code": self._last_exit_code,
                "current_bundle": str(self._current_bundle) if self._current_bundle else None,
                "run_dir": str(self.run_dir),
            }

    @property
    def current_bundle(self) -> Path | None:
        with self._lock:
            return self._current_bundle

    def stop(self) -> None:
        with self._lock:
            lifecycle = self._lifecycle
            process = self._process
        if lifecycle is not None and lifecycle.poll() is None:
            lifecycle.terminate()
            try:
                lifecycle.wait(timeout=5.0)
            except subprocess.TimeoutExpired:
                lifecycle.kill()
        if process is not None and process.poll() is None:
            try:
                rpc = JsonRpcClient(self.rpc_url, cookie_file=self.cookie_file, timeout=3.0)
                rpc.call("stop")
            except Exception:
                process.terminate()
            try:
                process.wait(timeout=15.0)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait(timeout=5.0)
        if self._node_stdout is not None:
            self._node_stdout.close()
        if self._node_stderr is not None:
            self._node_stderr.close()
