from __future__ import annotations

import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from goldatom_observatory.events import EventBus
from goldatom_observatory.lab import LiveLab, discover_bitcoind


class LiveLabContractTests(unittest.TestCase):
    def test_explicit_bitcoind_discovery(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            binary = Path(temp) / "bitcoind"
            binary.write_text("#!/bin/sh\nexit 0\n")
            binary.chmod(0o755)
            self.assertEqual(discover_bitcoind(binary), binary.resolve())

    def test_lab_allocates_private_run_directory_without_starting_node(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            binary = Path(temp) / "bitcoind"
            binary.write_text("#!/bin/sh\nexit 0\n")
            binary.chmod(0o755)
            run_root = Path(temp) / "runs"
            lab = LiveLab(EventBus(), bitcoind=binary, run_root=run_root, visual_delay=0)
            self.assertTrue(lab.run_dir.is_dir())
            self.assertTrue(lab.datadir.is_dir())
            self.assertEqual(lab.rpc_url.split(":")[0:2], ["http", "//127.0.0.1"])
            self.assertFalse(lab.journal_path.exists())


if __name__ == "__main__":
    unittest.main()
