"""Dependency-free HTTP and Server-Sent Events surface for the Observatory."""

from __future__ import annotations

import html
import json
import mimetypes
import threading
import urllib.parse
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any

from .evidence import DOCUMENT_ROOT, EVIDENCE_ROOT, PACKAGE_ROOT
from .util import json_bytes


STATIC_ROOT = PACKAGE_ROOT / "static"


class ObservatoryHTTPServer(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True

    def __init__(self, server_address: tuple[str, int], app: Any):
        super().__init__(server_address, ObservatoryHandler)
        self.app = app
        self.shutdown_event = threading.Event()

    def server_close(self) -> None:
        self.shutdown_event.set()
        super().server_close()


class ObservatoryHandler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    server_version = "GoldAtomObservatory/0.1"

    @property
    def app(self) -> Any:
        return self.server.app  # type: ignore[attr-defined]

    def log_message(self, format: str, *args: Any) -> None:
        # The UI event ledger is the primary operator surface. Keep polling noise out.
        quiet = ("/api/state", "/api/events", "/api/health", "/favicon.svg", "/assets/")
        if self.path.startswith(quiet):
            return
        super().log_message(format, *args)

    def _security_headers(self) -> None:
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header(
            "Content-Security-Policy",
            "default-src 'self'; connect-src 'self'; img-src 'self' data:; "
            "style-src 'self' 'unsafe-inline'; script-src 'self'; object-src 'none'; base-uri 'none'; "
            "frame-ancestors 'none'",
        )

    def _send_bytes(
        self,
        body: bytes,
        *,
        status: int = 200,
        content_type: str = "application/octet-stream",
        cache: str = "no-store",
        disposition: str | None = None,
    ) -> None:
        self.send_response(status)
        self._security_headers()
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", cache)
        if disposition:
            self.send_header("Content-Disposition", disposition)
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)

    def _send_json(self, value: Any, *, status: int = 200, pretty: bool = False) -> None:
        self._send_bytes(
            json_bytes(value, pretty=pretty),
            status=status,
            content_type="application/json; charset=utf-8",
        )

    def _send_error_json(self, status: int, message: str) -> None:
        self._send_json({"ok": False, "error": message}, status=status)

    @staticmethod
    def _safe_child(root: Path, name: str) -> Path | None:
        decoded = urllib.parse.unquote(name)
        candidate = (root / decoded).resolve()
        try:
            candidate.relative_to(root.resolve())
        except ValueError:
            return None
        return candidate if candidate.is_file() else None

    def _serve_static(self, relative: str) -> None:
        path = self._safe_child(STATIC_ROOT, relative)
        if path is None:
            self._send_error_json(404, "static asset not found")
            return
        content_type = mimetypes.guess_type(path.name)[0] or "application/octet-stream"
        if content_type.startswith("text/") or content_type in {"application/javascript", "image/svg+xml"}:
            content_type += "; charset=utf-8"
        self._send_bytes(
            path.read_bytes(),
            content_type=content_type,
            cache="public, max-age=300",
        )

    def _serve_document(self, name: str) -> None:
        path = self._safe_child(DOCUMENT_ROOT, name)
        if path is None:
            self._send_error_json(404, "document not found")
            return
        text = path.read_text(encoding="utf-8", errors="replace")
        body = f"""<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{html.escape(path.name)} · GoldAtom Observatory</title>
<style>body{{margin:0;background:#0a0a07;color:#e9e2cf;font:15px/1.65 ui-monospace,SFMono-Regular,Menlo,monospace}}main{{max-width:940px;margin:auto;padding:48px 24px 100px}}a{{color:#d5ad45}}pre{{white-space:pre-wrap;word-break:break-word;margin:0}}.bar{{position:sticky;top:0;background:#0a0a07e8;border-bottom:1px solid #3a3528;padding:12px 24px;backdrop-filter:blur(12px)}}.bar a{{text-decoration:none}}</style></head>
<body><div class="bar"><a href="/">← OBSERVATORY</a></div><main><pre>{html.escape(text)}</pre></main></body></html>"""
        self._send_bytes(body.encode(), content_type="text/html; charset=utf-8")

    def _serve_download(self, subpath: str) -> None:
        parts = subpath.split("/", 1)
        if len(parts) != 2:
            self._send_error_json(404, "download not found")
            return
        category, name = parts
        root = DOCUMENT_ROOT if category == "documents" else EVIDENCE_ROOT if category == "evidence" else None
        if root is None:
            self._send_error_json(404, "download category not found")
            return
        path = self._safe_child(root, name)
        if path is None:
            self._send_error_json(404, "download not found")
            return
        content_type = mimetypes.guess_type(path.name)[0] or "application/octet-stream"
        self._send_bytes(
            path.read_bytes(),
            content_type=content_type,
            disposition=f'attachment; filename="{path.name}"',
        )

    def _serve_sse(self, query: dict[str, list[str]]) -> None:
        try:
            last_id = int(self.headers.get("Last-Event-ID") or query.get("since", ["0"])[0])
        except ValueError:
            last_id = 0
        self.send_response(HTTPStatus.OK)
        self._security_headers()
        self.send_header("Content-Type", "text/event-stream; charset=utf-8")
        self.send_header("Cache-Control", "no-cache, no-transform")
        self.send_header("Connection", "keep-alive")
        self.send_header("X-Accel-Buffering", "no")
        self.end_headers()
        try:
            self.wfile.write(b"retry: 1200\n\n")
            self.wfile.flush()
            while not self.server.shutdown_event.is_set():  # type: ignore[attr-defined]
                events = self.app.bus.wait_after(last_id, timeout=12.0)
                if not events:
                    self.wfile.write(b": keepalive\n\n")
                    self.wfile.flush()
                    continue
                for event in events:
                    payload = json_bytes(event.to_dict())
                    frame = b"id: " + str(event.id).encode() + b"\n"
                    frame += b"event: observatory\n"
                    frame += b"data: " + payload + b"\n\n"
                    self.wfile.write(frame)
                    last_id = event.id
                self.wfile.flush()
        except (BrokenPipeError, ConnectionResetError, TimeoutError):
            return

    def do_HEAD(self) -> None:  # noqa: N802
        parsed = urllib.parse.urlparse(self.path)
        if parsed.path == "/api/events":
            self.send_response(HTTPStatus.METHOD_NOT_ALLOWED)
            self._security_headers()
            self.send_header("Allow", "GET")
            self.send_header("Content-Length", "0")
            self.end_headers()
            return
        self.do_GET()

    def do_GET(self) -> None:  # noqa: N802
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path
        query = urllib.parse.parse_qs(parsed.query)
        if path in {"/", "/index.html"}:
            self._serve_static("index.html")
            return
        if path.startswith("/assets/"):
            self._serve_static(path.removeprefix("/assets/"))
            return
        if path == "/favicon.svg":
            self._serve_static("favicon.svg")
            return
        if path == "/api/state":
            self._send_json(self.app.get_state())
            return
        if path == "/api/bundle":
            bundle = self.app.get_bundle()
            if bundle is None:
                self._send_error_json(404, "no proof bundle is loaded")
            else:
                self._send_json(bundle, pretty=True)
            return
        if path == "/api/events":
            self._serve_sse(query)
            return
        if path == "/api/health":
            state = self.app.get_state()
            self._send_json(
                {
                    "ok": True,
                    "mode": state["meta"]["mode"],
                    "connected": state["meta"]["connected"],
                    "updated_at": state["meta"]["updated_at"],
                }
            )
            return
        if path.startswith("/docs/"):
            self._serve_document(path.removeprefix("/docs/"))
            return
        if path.startswith("/download/"):
            self._serve_download(path.removeprefix("/download/"))
            return
        self._send_error_json(404, "route not found")

    def do_POST(self) -> None:  # noqa: N802
        if self.headers.get("X-GoldAtom-Action") != "1":
            self._send_error_json(403, "missing local action header")
            return
        parsed = urllib.parse.urlparse(self.path)
        prefix = "/api/action/"
        if not parsed.path.startswith(prefix):
            self._send_error_json(404, "route not found")
            return
        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            self._send_error_json(400, "invalid content length")
            return
        if length > 65_536:
            self._send_error_json(413, "request body is too large")
            return
        body = self.rfile.read(length) if length else b"{}"
        try:
            payload = json.loads(body or b"{}")
        except json.JSONDecodeError:
            self._send_error_json(400, "invalid JSON body")
            return
        if not isinstance(payload, dict):
            self._send_error_json(400, "action payload must be an object")
            return
        action_name = parsed.path.removeprefix(prefix)
        try:
            result = self.app.action(action_name, payload)
        except (ValueError, OSError, RuntimeError) as exc:
            self._send_error_json(400, str(exc))
            return
        self._send_json(result, status=200 if result.get("ok") else 409)
