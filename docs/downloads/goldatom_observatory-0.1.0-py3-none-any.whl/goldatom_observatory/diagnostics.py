"""Diagnostic projections for the GoldAtom verifier.

The normative verdict always comes from ``goldatom.verify.verify_bundle``. This module
projects that verdict into a stage-by-stage ledger suitable for a monitoring UI and
performs a few explicitly labelled offline recomputations.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from goldatom.models import GoldAtomBundle, Outpoint
from goldatom.profiles import get_profile
from goldatom.protocol import (
    atom_id,
    calculate_work_hash,
    claim_commitment,
    derive_challenge,
    expected_hashes,
    expected_work_log2,
    mint_commitment,
    target_to_int,
)
from goldatom.verify import VerificationError, VerificationReport


@dataclass(frozen=True, slots=True)
class CheckDefinition:
    id: str
    label: str
    stage: str


CHECKS: tuple[CheckDefinition, ...] = (
    CheckDefinition("profile", "Protocol profile recognized", "claim"),
    CheckDefinition("network", "Bitcoin network matches profile", "claim"),
    CheckDefinition("claim_header", "Claim block is canonical", "claim"),
    CheckDefinition("claim_inclusion", "Claim transaction inclusion proof", "claim"),
    CheckDefinition("claim_commitment", "Claim commitment and marker", "claim"),
    CheckDefinition("challenge_header", "Future challenge block is canonical", "challenge"),
    CheckDefinition("challenge_digest", "Challenge digest recomputes", "challenge"),
    CheckDefinition("work_hash", "80-byte SHA-256d work hash recomputes", "work"),
    CheckDefinition("work_target", "Work hash satisfies committed target", "work"),
    CheckDefinition("mint_window", "Mint lands inside the allowed window", "mint"),
    CheckDefinition("mint_inclusion", "Mint transaction inclusion proof", "mint"),
    CheckDefinition("claim_consumed", "Mint consumes the claim seal", "mint"),
    CheckDefinition("mint_commitment", "Mint commitment and marker", "mint"),
    CheckDefinition("title_chain", "Title ancestry is contiguous", "title"),
    CheckDefinition("title_utxo", "Terminal title exists and is unspent", "title"),
    CheckDefinition("burial", "Minimum Bitcoin burial is satisfied", "burial"),
)


def terminal_outpoint(bundle: GoldAtomBundle) -> Outpoint:
    if bundle.transfers:
        final = bundle.transfers[-1]
        return Outpoint(final.txid, final.successor_vout)
    return Outpoint(bundle.mint.txid, bundle.mint.title_vout)


def calculate_atom_id(bundle: GoldAtomBundle) -> str:
    return atom_id(
        mint_txid=bundle.mint.txid,
        title_vout=bundle.mint.title_vout,
        mint_commitment_digest=bytes.fromhex(bundle.mint.commitment_hex),
    ).hex()


def offline_facts(bundle: GoldAtomBundle) -> dict[str, Any]:
    """Recompute protocol-internal facts without claiming Bitcoin canonicality."""
    profile = get_profile(bundle.profile)
    claim_digest = claim_commitment(
        profile,
        seal_vout=bundle.claim.outpoint.vout,
        seal_script_hex=bundle.claim.seal_script_hex,
        algorithm=bundle.claim.algorithm,
        target_hex=bundle.claim.target_hex,
    )
    challenge_digest = derive_challenge(
        profile,
        claim_outpoint=bundle.claim.outpoint,
        claim_block_hash=bundle.claim.block_hash,
        claim_commitment_digest=claim_digest,
        challenge_block_hash=bundle.work.challenge_block_hash,
    )
    work_hash = calculate_work_hash(
        challenge_digest=challenge_digest,
        claim_commitment_digest=claim_digest,
        extra_nonce=bundle.work.extra_nonce,
        nonce=bundle.work.nonce,
    )
    mint_digest = mint_commitment(
        profile,
        claim_outpoint=bundle.claim.outpoint,
        challenge_digest=challenge_digest,
        extra_nonce=bundle.work.extra_nonce,
        nonce=bundle.work.nonce,
        work_hash=work_hash,
        title_vout=bundle.mint.title_vout,
        title_script_hex=bundle.mint.title_script_hex,
    )
    target = target_to_int(bundle.claim.target_hex)
    attempts = bundle.work.extra_nonce * (1 << 32) + bundle.work.nonce + 1
    return {
        "atom_id": calculate_atom_id(bundle),
        "profile": profile.id,
        "network": profile.network,
        "claim_commitment_recomputes": claim_digest.hex() == bundle.claim.commitment_hex,
        "challenge_recomputes": challenge_digest.hex() == bundle.work.challenge_digest_hex,
        "work_hash_recomputes": work_hash.hex() == bundle.work.work_hash_hex,
        "work_satisfies_target": int.from_bytes(work_hash, "big") <= target,
        "mint_commitment_recomputes": mint_digest.hex() == bundle.mint.commitment_hex,
        "expected_hashes": expected_hashes(target),
        "expected_work_log2": expected_work_log2(target),
        "attempts": attempts,
        "terminal_outpoint": terminal_outpoint(bundle).to_dict(),
    }


def _empty_checks(status: str = "pending", source: str = "live verifier") -> list[dict[str, Any]]:
    return [
        {
            "id": item.id,
            "label": item.label,
            "stage": item.stage,
            "status": status,
            "source": source,
            "detail": "",
        }
        for item in CHECKS
    ]


def checks_from_report(report: VerificationReport) -> list[dict[str, Any]]:
    checks = _empty_checks("pass", "live verifier")
    for check in checks:
        check["detail"] = "Verified against the active Bitcoin Core view."
    return checks


def offline_checks(bundle: GoldAtomBundle, *, recorded_pass: bool = False) -> list[dict[str, Any]]:
    facts = offline_facts(bundle)
    checks = _empty_checks("pending", "requires Bitcoin Core")

    local = {
        "profile": True,
        "claim_commitment": facts["claim_commitment_recomputes"],
        "challenge_digest": facts["challenge_recomputes"],
        "work_hash": facts["work_hash_recomputes"],
        "work_target": facts["work_satisfies_target"],
        "mint_commitment": facts["mint_commitment_recomputes"],
        "title_chain": True,
    }
    for check in checks:
        if check["id"] in local:
            check["status"] = "pass" if local[check["id"]] else "fail"
            check["source"] = "local recomputation"
            check["detail"] = "Recomputed from the proof bundle; canonical chain state is not asserted."
        elif recorded_pass:
            check["status"] = "recorded"
            check["source"] = "recorded Core validation"
            check["detail"] = "Passed in the bundled Bitcoin Core validation transcript."
    return checks


def _failure_check_id(error: VerificationError) -> str:
    code = error.code
    msg = error.message.lower()
    direct = {
        "UNKNOWN_PROFILE": "profile",
        "WRONG_NETWORK": "network",
        "BAD_CLAIM_COMMITMENT": "claim_commitment",
        "CLAIM_MARKER_COUNT": "claim_commitment",
        "BAD_CHALLENGE_HEIGHT": "challenge_header",
        "BAD_CHALLENGE": "challenge_digest",
        "BAD_WORK_HASH": "work_hash",
        "INSUFFICIENT_WORK": "work_target",
        "MINT_OUTSIDE_WINDOW": "mint_window",
        "CLAIM_NOT_CONSUMED": "claim_consumed",
        "TITLE_SCRIPT_MISMATCH": "mint_commitment",
        "UNSUPPORTED_TITLE_SCRIPT": "mint_commitment",
        "BAD_MINT_COMMITMENT": "mint_commitment",
        "MINT_MARKER_COUNT": "mint_commitment",
        "TRANSFER_INDEX": "title_chain",
        "BROKEN_TITLE_CHAIN": "title_chain",
        "TRANSFER_ORDER": "title_chain",
        "TITLE_NOT_CONSUMED": "title_chain",
        "SUCCESSOR_SCRIPT_MISMATCH": "title_chain",
        "BAD_TRANSFER_COMMITMENT": "title_chain",
        "TRANSFER_MARKER_COUNT": "title_chain",
        "TITLE_SPENT_OR_MISSING": "title_utxo",
        "CURRENT_TITLE_MISMATCH": "title_utxo",
        "CURRENT_TITLE_VALUE": "title_utxo",
        "CURRENT_TITLE_UNCONFIRMED": "title_utxo",
        "INSUFFICIENT_BURIAL": "burial",
        "INSUFFICIENT_CHAINWORK": "burial",
        "BAD_TIP": "burial",
    }
    if code in direct:
        return direct[code]
    if code in {"HEADER_LOOKUP", "HEADER_MISMATCH", "NONCANONICAL_BLOCK", "REORGED_BLOCK"}:
        if "claim" in msg:
            return "claim_header"
        if "challenge" in msg:
            return "challenge_header"
        if "mint" in msg:
            return "mint_inclusion"
        return "title_chain"
    if code in {"BAD_INCLUSION_PROOF", "TRANSACTION_LOOKUP", "TRANSACTION_MISMATCH", "MISSING_OUTPUT"}:
        if "claim" in msg:
            return "claim_inclusion"
        if "mint" in msg:
            return "mint_inclusion"
        return "title_chain"
    if code in {"CLAIM_SEAL_MISMATCH", "UNSUPPORTED_CLAIM_SEAL"}:
        return "claim_commitment"
    return "profile"


def checks_from_error(error: VerificationError) -> list[dict[str, Any]]:
    failure_id = _failure_check_id(error)
    checks = _empty_checks()
    failure_index = next((i for i, item in enumerate(CHECKS) if item.id == failure_id), 0)
    for i, check in enumerate(checks):
        if i < failure_index:
            check["status"] = "pass"
            check["detail"] = "Verifier passed this gate before stopping."
        elif i == failure_index:
            check["status"] = "fail"
            check["detail"] = f"{error.code}: {error.message}"
        else:
            check["status"] = "blocked"
            check["detail"] = "Not reached because an earlier verifier gate failed."
    return checks
