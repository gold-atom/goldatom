# GoldAtom Observatory Architecture

```text
                          ┌──────────────────────────────┐
                          │ Browser instrument panel     │
                          │ HTML · CSS · vanilla JS      │
                          └──────────────┬───────────────┘
                                         │
                           state JSON + Server-Sent Events
                                         │
                          ┌──────────────▼───────────────┐
                          │ stdlib threaded HTTP server  │
                          │ security headers · actions  │
                          └──────────────┬───────────────┘
                                         │
                      ┌──────────────────┴──────────────────┐
                      │                                     │
          ┌───────────▼───────────┐             ┌──────────▼───────────┐
          │ ReplayMonitor          │             │ CoreMonitor           │
          │ preserved evidence     │             │ read-only RPC polling │
          │ explicit source labels │             │ continuous verifier   │
          └───────────┬───────────┘             └──────────┬───────────┘
                      │                                     │
              packaged evidence                         Bitcoin Core
                                                            │
                                                 optional isolated lab
                                                            │
                                           instrumented lifecycle module
                                                            │
                                             append-only JSONL journal
```

## Trust separation

The projection has three evidence classes:

1. **Protocol-local facts** — commitments, challenge digest, work hash, target test, Atom ID, and title ancestry can be recomputed from the proof object.
2. **Active-chain facts** — canonical headers, inclusion, UTXO status, confirmation depth, and chainwork require a Bitcoin view.
3. **Recorded claims** — replay mode displays results preserved from a prior Core run and labels them as recorded rather than current.

The server does not collapse these classes into one green status.

## Event path

`EventBus` is a bounded, thread-safe append-only stream. The browser receives events through SSE with monotonic IDs and reconnects using `Last-Event-ID`. A `JournalTailer` separately follows structured JSONL emitted by the lifecycle process and republishes it into the same stream.

## Process boundary

`CoreMonitor` is read-only. `LiveLab` is the only component that starts a node or lifecycle process. It always creates a new datadir, uses regtest, disables P2P listening, and keeps process controls behind an explicitly selected lab command.

## UI update model

The browser fetches `/api/state` on load and after each SSE event. The response is a coherent snapshot protected by monitor locks. This avoids deriving consensus state incrementally in JavaScript; the browser is a projection surface, not a verifier.
