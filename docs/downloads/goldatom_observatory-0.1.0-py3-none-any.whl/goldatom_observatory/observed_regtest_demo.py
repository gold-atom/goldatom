#!/usr/bin/env python3
"""Create a GoldAtom/0 on a running regtest node while emitting JSONL telemetry."""

from __future__ import annotations

import argparse
import sys
import time
from decimal import Decimal
from pathlib import Path
from urllib.parse import quote

from goldatom.core_rpc import CoreBitcoinView, JsonRpcClient, RpcError
from goldatom.encoding import marker_payload, marker_script
from goldatom.models import ClaimRecord, GoldAtomBundle, MintRecord, Outpoint, WorkRecord
from goldatom.profiles import ALGORITHM_SHA256D_80_V0, get_profile
from goldatom.protocol import claim_commitment, derive_challenge, mine_work, mint_commitment
from goldatom.verify import VerificationError, verify_bundle
from goldatom_observatory.journal import JournalWriter


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--rpc-url", default="http://127.0.0.1:18443")
    parser.add_argument("--rpc-user")
    parser.add_argument("--rpc-password")
    parser.add_argument("--cookie-file")
    parser.add_argument("--wallet", default="goldatom-observatory")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--journal", type=Path)
    parser.add_argument(
        "--visual-delay",
        type=float,
        default=0.55,
        help="presentation-only pause between milestones; does not alter protocol rules",
    )
    return parser.parse_args(argv)


def pause(seconds: float) -> None:
    if seconds > 0:
        time.sleep(seconds)


def ensure_wallet(base: JsonRpcClient, name: str) -> JsonRpcClient:
    loaded = set(base.call("listwallets"))
    if name not in loaded:
        available = {item["name"] for item in base.call("listwalletdir")["wallets"]}
        if name in available:
            base.call("loadwallet", name)
        else:
            base.call("createwallet", name)
    return base.child(f"wallet/{quote(name, safe='')}")


def mine_blocks(wallet: JsonRpcClient, count: int) -> list[str]:
    address = wallet.call("getnewaddress", "goldatom-mining", "bech32m")
    return wallet.call("generatetoaddress", count, address)


def assert_output(decoded: dict, index: int, script_hex: str, role: str) -> None:
    try:
        actual = decoded["vout"][index]["scriptPubKey"]["hex"]
    except (KeyError, IndexError) as exc:
        raise RuntimeError(f"{role} output {index} missing after construction") from exc
    if actual != script_hex:
        raise RuntimeError(f"{role} output order changed: expected {script_hex}, got {actual}")


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)
    if args.cookie_file and (args.rpc_user or args.rpc_password):
        raise SystemExit("Use cookie authentication or username/password, not both.")
    journal = JournalWriter(args.journal)
    journal.emit(
        "lifecycle.started",
        "Fresh GoldAtom lifecycle started",
        "Connecting to an isolated Bitcoin Core regtest node.",
        severity="signal",
        stage="node",
    )
    base = JsonRpcClient(
        args.rpc_url,
        username=args.rpc_user,
        password=args.rpc_password,
        cookie_file=args.cookie_file,
    )
    chain_info = base.call("getblockchaininfo")
    if chain_info["chain"] != "regtest":
        raise SystemExit(
            f"Refusing to run: expected regtest, Core reports {chain_info['chain']!r}."
        )
    journal.emit(
        "node.connected",
        "Bitcoin Core connected",
        f"Regtest best height is {chain_info['blocks']}.",
        severity="success",
        stage="node",
        height=int(chain_info["blocks"]),
        tip_hash=chain_info["bestblockhash"],
    )
    pause(args.visual_delay)

    wallet = ensure_wallet(base, args.wallet)
    if Decimal(str(wallet.call("getbalance"))) < Decimal("0.01"):
        journal.emit(
            "funds.mining",
            "Maturing regtest funds",
            "Mining 101 blocks so the wallet can spend a coinbase output.",
            severity="info",
            stage="node",
            blocks=101,
        )
        print("Mining 101 regtest blocks to create mature wallet funds...", file=sys.stderr)
        mine_blocks(wallet, 101)
        height = int(base.call("getblockcount"))
        journal.emit(
            "funds.ready",
            "Wallet funds matured",
            f"The private regtest chain reached height {height}.",
            severity="success",
            stage="node",
            height=height,
        )
        pause(args.visual_delay)

    profile = get_profile("goldatom-regtest-v0")
    target_hex = profile.maximum_target_hex

    journal.emit(
        "claim.constructing",
        "Constructing claim seal",
        "Committing the algorithm, target, challenge delay, and spendable P2TR seal.",
        severity="info",
        stage="claim",
        target=target_hex,
        algorithm=ALGORITHM_SHA256D_80_V0,
    )
    claim_address = wallet.call("getnewaddress", "goldatom-claim", "bech32m")
    claim_seal_script = wallet.call("getaddressinfo", claim_address)["scriptPubKey"]
    claim_digest = claim_commitment(
        profile,
        seal_vout=0,
        seal_script_hex=claim_seal_script,
        algorithm=ALGORITHM_SHA256D_80_V0,
        target_hex=target_hex,
    )
    claim_marker_script = marker_script("claim", claim_digest).hex()
    unsigned_claim = wallet.call(
        "createrawtransaction",
        [],
        [
            {claim_address: "0.00100000"},
            {"data": marker_payload("claim", claim_digest).hex()},
        ],
    )
    funded_claim = wallet.call(
        "fundrawtransaction",
        unsigned_claim,
        {"changePosition": 2, "fee_rate": "1.0"},
    )
    signed_claim = wallet.call("signrawtransactionwithwallet", funded_claim["hex"])
    if signed_claim.get("complete") is not True:
        raise RuntimeError("wallet did not completely sign the claim transaction")
    decoded_claim = wallet.call("decoderawtransaction", signed_claim["hex"])
    assert_output(decoded_claim, 0, claim_seal_script, "claim seal")
    assert_output(decoded_claim, 1, claim_marker_script, "claim marker")
    claim_txid = wallet.call("sendrawtransaction", signed_claim["hex"])
    journal.emit(
        "claim.broadcast",
        "Claim broadcast",
        "The precommitment is in the mempool and cannot be revised without changing its txid.",
        severity="signal",
        stage="claim",
        txid=claim_txid,
        commitment=claim_digest.hex(),
    )
    pause(args.visual_delay)
    mine_blocks(wallet, 1)
    claim_wallet_tx = wallet.call("gettransaction", claim_txid)
    claim_block_hash = claim_wallet_tx["blockhash"]
    claim_header = base.call("getblockheader", claim_block_hash, True)
    claim_height = int(claim_header["height"])
    claim_outpoint = Outpoint(claim_txid, 0)
    claim_proof = base.call("gettxoutproof", [claim_txid], claim_block_hash)
    print(f"Claim confirmed at height {claim_height}: {claim_outpoint}", file=sys.stderr)
    journal.emit(
        "claim.confirmed",
        "Claim seal confirmed",
        f"Bitcoin fixed the claim at height {claim_height} before its future challenge existed.",
        severity="success",
        stage="claim",
        height=claim_height,
        block_hash=claim_block_hash,
        outpoint=str(claim_outpoint),
    )
    pause(args.visual_delay)

    expected_challenge_height = claim_height + profile.challenge_delay
    current_height = int(base.call("getblockcount"))
    journal.emit(
        "challenge.waiting",
        "Waiting for unknowable future history",
        f"The challenge will be fixed at height {expected_challenge_height}.",
        severity="info",
        stage="challenge",
        current_height=current_height,
        challenge_height=expected_challenge_height,
    )
    while current_height < expected_challenge_height:
        block_hash = mine_blocks(wallet, 1)[0]
        current_height += 1
        journal.emit(
            "block.connected",
            f"Regtest block {current_height} connected",
            "Future chain history advanced by one block.",
            severity="info",
            stage="challenge",
            height=current_height,
            block_hash=block_hash,
        )
        pause(args.visual_delay)
    challenge_block_hash = base.call("getblockhash", expected_challenge_height)
    challenge_digest = derive_challenge(
        profile,
        claim_outpoint=claim_outpoint,
        claim_block_hash=claim_block_hash,
        claim_commitment_digest=claim_digest,
        challenge_block_hash=challenge_block_hash,
    )
    print(
        f"Challenge fixed by block {expected_challenge_height}: {challenge_block_hash}",
        file=sys.stderr,
    )
    journal.emit(
        "challenge.locked",
        "Challenge locked by Bitcoin",
        "The work problem now contains a canonical future block the claimant could not know at claim time.",
        severity="signal",
        stage="challenge",
        height=expected_challenge_height,
        block_hash=challenge_block_hash,
        digest=challenge_digest.hex(),
    )
    pause(args.visual_delay)

    journal.emit(
        "work.started",
        "Local extraction started",
        "Searching the fixed 80-byte SHA-256d header below the committed target.",
        severity="warning",
        stage="work",
        expected_hashes=16,
        target=target_hex,
    )
    mined = mine_work(
        challenge_digest=challenge_digest,
        claim_commitment_digest=claim_digest,
        target=profile.maximum_target,
        max_attempts=1_000_000,
    )
    print(
        f"Local proof found after {mined.attempts} attempts: {mined.work_hash.hex()}",
        file=sys.stderr,
    )
    pause(args.visual_delay)
    journal.emit(
        "work.found",
        "Exclusive local proof found",
        f"Attempt {mined.attempts} satisfied the precommitted target.",
        severity="success",
        stage="work",
        attempts=mined.attempts,
        extra_nonce=mined.extra_nonce,
        nonce=mined.nonce,
        work_hash=mined.work_hash.hex(),
    )
    pause(args.visual_delay)

    journal.emit(
        "mint.constructing",
        "Constructing mint and title seal",
        "The claim outpoint will be consumed exactly once into a new P2TR title output.",
        severity="info",
        stage="mint",
    )
    title_address = wallet.call("getnewaddress", "goldatom-title", "bech32m")
    title_script = wallet.call("getaddressinfo", title_address)["scriptPubKey"]
    mint_digest = mint_commitment(
        profile,
        claim_outpoint=claim_outpoint,
        challenge_digest=challenge_digest,
        extra_nonce=mined.extra_nonce,
        nonce=mined.nonce,
        work_hash=mined.work_hash,
        title_vout=0,
        title_script_hex=title_script,
    )
    mint_marker_script = marker_script("mint", mint_digest).hex()
    unsigned_mint = wallet.call(
        "createrawtransaction",
        [{"txid": claim_txid, "vout": 0}],
        [
            {title_address: "0.00098000"},
            {"data": marker_payload("mint", mint_digest).hex()},
        ],
    )
    signed_mint = wallet.call("signrawtransactionwithwallet", unsigned_mint)
    if signed_mint.get("complete") is not True:
        raise RuntimeError("wallet did not completely sign the mint transaction")
    decoded_mint = wallet.call("decoderawtransaction", signed_mint["hex"])
    assert_output(decoded_mint, 0, title_script, "title")
    assert_output(decoded_mint, 1, mint_marker_script, "mint marker")
    acceptance = base.call("testmempoolaccept", [signed_mint["hex"]])
    if not acceptance or acceptance[0].get("allowed") is not True:
        raise RuntimeError(f"Bitcoin Core rejected mint transaction: {acceptance}")
    mint_txid = wallet.call("sendrawtransaction", signed_mint["hex"])
    journal.emit(
        "mint.broadcast",
        "Mint accepted into mempool",
        "The transaction spends the single-use claim seal and designates one title output.",
        severity="signal",
        stage="mint",
        txid=mint_txid,
        commitment=mint_digest.hex(),
    )
    pause(args.visual_delay)
    mine_blocks(wallet, 1)
    mint_wallet_tx = wallet.call("gettransaction", mint_txid)
    mint_block_hash = mint_wallet_tx["blockhash"]
    mint_header = base.call("getblockheader", mint_block_hash, True)
    mint_height = int(mint_header["height"])
    mint_proof = base.call("gettxoutproof", [mint_txid], mint_block_hash)
    journal.emit(
        "mint.confirmed",
        "Atom minted",
        f"The mint and title seal were confirmed at height {mint_height}.",
        severity="success",
        stage="mint",
        height=mint_height,
        block_hash=mint_block_hash,
        txid=mint_txid,
        title_outpoint=f"{mint_txid}:0",
    )
    pause(args.visual_delay)

    journal.emit(
        "burial.started",
        "Accumulating post-mint chainwork",
        f"The {profile.id} profile requires {profile.minimum_burial_blocks} subsequent block.",
        severity="info",
        stage="burial",
        required_blocks=profile.minimum_burial_blocks,
    )
    burial_hashes = mine_blocks(wallet, profile.minimum_burial_blocks)
    tip_height = int(base.call("getblockcount"))
    journal.emit(
        "burial.complete",
        "Proof burial complete",
        f"Bitcoin advanced to height {tip_height}; the mint now has required burial.",
        severity="success",
        stage="burial",
        tip_height=tip_height,
        block_hash=burial_hashes[-1],
    )
    pause(args.visual_delay)

    bundle = GoldAtomBundle(
        profile=profile.id,
        claim=ClaimRecord(
            outpoint=claim_outpoint,
            block_hash=claim_block_hash,
            height=claim_height,
            seal_script_hex=claim_seal_script,
            algorithm=ALGORITHM_SHA256D_80_V0,
            target_hex=target_hex,
            commitment_hex=claim_digest.hex(),
            txout_proof=claim_proof,
        ),
        work=WorkRecord(
            challenge_height=expected_challenge_height,
            challenge_block_hash=challenge_block_hash,
            challenge_digest_hex=challenge_digest.hex(),
            extra_nonce=mined.extra_nonce,
            nonce=mined.nonce,
            work_hash_hex=mined.work_hash.hex(),
        ),
        mint=MintRecord(
            txid=mint_txid,
            block_hash=mint_block_hash,
            height=mint_height,
            txout_proof=mint_proof,
            title_vout=0,
            title_script_hex=title_script,
            commitment_hex=mint_digest.hex(),
        ),
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    bundle.write(args.output)
    journal.emit(
        "bundle.written",
        "Portable proof bundle written",
        str(args.output),
        severity="info",
        stage="title",
        path=str(args.output),
    )
    pause(args.visual_delay)

    journal.emit(
        "verification.started",
        "Independent assay started",
        "The proof bundle is being checked against the active Core view.",
        severity="info",
        stage="title",
    )
    report = verify_bundle(bundle, CoreBitcoinView(base))
    print(report.pretty())
    print(f"\nProof bundle written to {args.output}")
    journal.emit(
        "verification.pass",
        "VALID GOLDATOM / 0",
        "Every normative verifier gate passed against the active Bitcoin chain.",
        severity="success",
        stage="title",
        atom_id=report.atom_id,
        current_title=str(report.current_title_outpoint),
        burial_blocks=report.burial_blocks,
        burial_chainwork=str(report.burial_chainwork),
    )
    journal.emit(
        "adversarial.started",
        "Adversarial validation started",
        "Mutations and a reversible challenge-block reorganization will now attack the atom.",
        severity="warning",
        stage="title",
        atom_id=report.atom_id,
    )
    pause(args.visual_delay)

    def mutate_final_nibble(value: str) -> str:
        return value[:-1] + ("0" if value[-1] != "0" else "1")

    work_tamper = bundle.to_dict()
    work_tamper["work"]["work_hash_hex"] = mutate_final_nibble(
        work_tamper["work"]["work_hash_hex"]
    )
    try:
        verify_bundle(GoldAtomBundle.from_dict(work_tamper), CoreBitcoinView(base))
    except VerificationError as exc:
        if exc.code != "BAD_WORK_HASH":
            raise
        journal.emit(
            "tamper.work.rejected",
            "Mutated work hash rejected",
            f"The verifier stopped with {exc.code}.",
            severity="success",
            stage="work",
            code=exc.code,
        )
    else:
        raise RuntimeError("tampered work hash unexpectedly verified")
    pause(args.visual_delay)

    challenge_tamper = bundle.to_dict()
    challenge_tamper["work"]["challenge_digest_hex"] = mutate_final_nibble(
        challenge_tamper["work"]["challenge_digest_hex"]
    )
    try:
        verify_bundle(GoldAtomBundle.from_dict(challenge_tamper), CoreBitcoinView(base))
    except VerificationError as exc:
        if exc.code != "BAD_CHALLENGE":
            raise
        journal.emit(
            "tamper.challenge.rejected",
            "Mutated challenge rejected",
            f"The verifier stopped with {exc.code}.",
            severity="success",
            stage="challenge",
            code=exc.code,
        )
    else:
        raise RuntimeError("tampered challenge unexpectedly verified")
    pause(args.visual_delay)

    before_reorg = base.call("getblockchaininfo")
    journal.emit(
        "reorg.started",
        "Withdrawing the challenge block",
        "Bitcoin Core will invalidate the challenge and every dependent descendant.",
        severity="error",
        stage="challenge",
        challenge_block=challenge_block_hash,
        tip_height=int(before_reorg["blocks"]),
    )
    base.call("invalidateblock", challenge_block_hash)
    pause(max(1.2, args.visual_delay * 2.2))
    try:
        verify_bundle(bundle, CoreBitcoinView(base))
    except VerificationError as exc:
        journal.emit(
            "reorg.rejected",
            "Noncanonical atom rejected",
            f"Removing the challenge history invalidated the atom with {exc.code}.",
            severity="success",
            stage="challenge",
            code=exc.code,
            new_tip_height=int(base.call("getblockcount")),
        )
    else:
        raise RuntimeError("challenge reorganization unexpectedly preserved validity")
    pause(args.visual_delay)

    journal.emit(
        "reorg.restoring",
        "Restoring canonical history",
        "Reconsidering the challenge block and its descendants.",
        severity="signal",
        stage="challenge",
        challenge_block=challenge_block_hash,
    )
    base.call("reconsiderblock", challenge_block_hash)
    pause(max(1.2, args.visual_delay * 2.2))
    restored = verify_bundle(bundle, CoreBitcoinView(base))
    journal.emit(
        "reorg.restored",
        "Atom validity restored",
        "The unchanged proof verifies again because its committed history is canonical again.",
        severity="success",
        stage="title",
        atom_id=restored.atom_id,
        tip_height=restored.as_of_tip_height,
    )

    journal.emit(
        "lifecycle.complete",
        "Fresh digital matter created and attacked",
        "The node remains available for continuous reassay in the Observatory.",
        severity="signal",
        stage="title",
        atom_id=report.atom_id,
        bundle=str(args.output),
    )
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (RpcError, OSError, ConnectionError, RuntimeError, ValueError) as exc:
        try:
            args = parse_args()
            JournalWriter(args.journal).emit(
                "lifecycle.failed",
                "Lifecycle failed",
                str(exc),
                severity="error",
                stage="node",
            )
        except Exception:
            pass
        print(f"observed regtest demo failed: {exc}", file=sys.stderr)
        raise SystemExit(2)
