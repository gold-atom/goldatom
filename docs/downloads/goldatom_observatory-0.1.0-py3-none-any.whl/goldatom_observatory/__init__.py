"""GoldAtom Observatory: a local-first live instrument for Proof-Buried Work."""

__version__ = "0.1.0"
