"""Command-line entry point for GoldAtom Observatory."""

from __future__ import annotations

import argparse
import os
import signal
import threading
import time
import webbrowser
from pathlib import Path

from . import __version__
from .app import ObservatoryApplication
from .events import EventBus
from .lab import LiveLab, discover_bitcoind
from .monitor import CoreMonitor
from .replay import ReplayMonitor
from .server import ObservatoryHTTPServer


DEFAULT_PORT = 8787


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="goldatom-observatory",
        description="Local-first live dashboard for the GoldAtom research protocol.",
    )
    parser.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    sub = parser.add_subparsers(dest="command")

    serve = sub.add_parser("serve", help="serve a replay or attach to an existing Core node")
    serve.add_argument("--mode", choices=("replay", "core"), default="replay")
    serve.add_argument("--host", default="127.0.0.1")
    serve.add_argument(
        "--unsafe-public",
        action="store_true",
        help="allow binding beyond loopback; the Observatory has no user authentication",
    )
    serve.add_argument("--port", type=int, default=DEFAULT_PORT)
    serve.add_argument("--no-open", action="store_true")
    serve.add_argument("--speed", type=float, default=1.0, help="replay speed, 0.25 to 8")
    serve.add_argument("--rpc-url", default="http://127.0.0.1:18443")
    serve.add_argument("--rpc-user")
    serve.add_argument("--rpc-password")
    serve.add_argument("--cookie-file")
    serve.add_argument("--bundle", type=Path)
    serve.add_argument("--journal", type=Path)
    serve.add_argument("--poll", type=float, default=1.25)

    lab = sub.add_parser("lab", help="start an isolated Core node and visibly mint a fresh test atom")
    lab.add_argument("--bitcoind", type=Path)
    lab.add_argument("--run-root", type=Path, default=Path.cwd() / "goldatom-runs")
    lab.add_argument("--host", default="127.0.0.1")
    lab.add_argument(
        "--unsafe-public",
        action="store_true",
        help="allow binding beyond loopback; the lab exposes regtest process controls",
    )
    lab.add_argument("--port", type=int, default=DEFAULT_PORT)
    lab.add_argument("--no-open", action="store_true")
    lab.add_argument("--no-auto-run", action="store_true")
    lab.add_argument("--visual-delay", type=float, default=0.55)
    lab.add_argument("--poll", type=float, default=0.6)
    return parser


def _is_loopback_host(host: str) -> bool:
    normalized = host.strip().lower()
    return normalized in {"127.0.0.1", "localhost", "::1"}


def _enforce_bind_policy(host: str, *, unsafe_public: bool) -> None:
    if not _is_loopback_host(host) and not unsafe_public:
        raise SystemExit(
            "Refusing to bind the unauthenticated Observatory beyond loopback. "
            "Pass --unsafe-public only inside a trusted network or isolated container."
        )


def _default_cookie() -> Path | None:
    explicit = os.environ.get("BITCOIN_RPC_COOKIE")
    candidates = [
        Path(explicit).expanduser() if explicit else None,
        Path.home() / ".bitcoin" / "regtest" / ".cookie",
        Path.home() / ".bitcoin" / ".cookie",
    ]
    return next((path for path in candidates if path is not None and path.is_file()), None)


def _serve(app: ObservatoryApplication, host: str, port: int, *, open_browser: bool) -> int:
    server = ObservatoryHTTPServer((host, port), app)
    actual_port = int(server.server_address[1])
    browser_host = "127.0.0.1" if host in {"0.0.0.0", "::"} else host
    rendered_host = f"[{browser_host}]" if ":" in browser_host else browser_host
    url = f"http://{rendered_host}:{actual_port}/"
    app.bus.publish(
        "observatory.ready",
        f"GoldAtom Observatory listening at {url}",
        level="success",
        data={"url": url},
    )
    print("\nGOLDATOM OBSERVATORY")
    print(f"  {url}")
    print("  Press Ctrl-C to stop.\n")
    if open_browser:
        threading.Timer(0.35, lambda: webbrowser.open(url)).start()

    previous_sigterm = None
    if threading.current_thread() is threading.main_thread():
        previous_sigterm = signal.getsignal(signal.SIGTERM)

        def stop_on_sigterm(_signum: int, _frame: object) -> None:
            raise KeyboardInterrupt

        signal.signal(signal.SIGTERM, stop_on_sigterm)
    try:
        server.serve_forever(poll_interval=0.3)
    except KeyboardInterrupt:
        print("\nStopping Observatory...")
    finally:
        server.server_close()
        app.close()
        if previous_sigterm is not None:
            signal.signal(signal.SIGTERM, previous_sigterm)
    return 0


def _serve_command(args: argparse.Namespace) -> int:
    _enforce_bind_policy(args.host, unsafe_public=args.unsafe_public)
    bus = EventBus()
    if args.mode == "replay":
        monitor = ReplayMonitor(bus, speed=args.speed)
    else:
        cookie = Path(args.cookie_file).expanduser() if args.cookie_file else _default_cookie()
        if cookie is None and not (args.rpc_user and args.rpc_password):
            raise SystemExit(
                "Core mode needs --cookie-file or --rpc-user/--rpc-password. "
                "Replay mode works without a node."
            )
        monitor = CoreMonitor(
            bus,
            rpc_url=args.rpc_url,
            rpc_user=args.rpc_user,
            rpc_password=args.rpc_password,
            cookie_file=cookie,
            bundle_path=args.bundle,
            poll_interval=args.poll,
        )
    app = ObservatoryApplication(monitor, bus, journal_path=args.journal)
    return _serve(app, args.host, args.port, open_browser=not args.no_open)


def _lab_command(args: argparse.Namespace) -> int:
    _enforce_bind_policy(args.host, unsafe_public=args.unsafe_public)
    binary = discover_bitcoind(args.bitcoind)
    if binary is None:
        raise SystemExit(
            "No executable bitcoind was found. Pass --bitcoind /path/to/bitcoind "
            "or set the BITCOIND environment variable."
        )
    bus = EventBus()
    lab = LiveLab(
        bus,
        bitcoind=binary,
        run_root=args.run_root,
        visual_delay=args.visual_delay,
    )
    try:
        lab.start_node()
        monitor = CoreMonitor(
            bus,
            rpc_url=lab.rpc_url,
            cookie_file=lab.cookie_file,
            bundle_path=None,
            poll_interval=args.poll,
        )
        lab.attach_bundle_callback(monitor.set_bundle_path)
        app = ObservatoryApplication(
            monitor,
            bus,
            journal_path=lab.journal_path,
            run_action=lab,
        )
        if not args.no_auto_run:
            threading.Timer(1.2, lab.start_lifecycle).start()
        return _serve(app, args.host, args.port, open_browser=not args.no_open)
    except Exception:
        lab.stop()
        raise


def main(argv: list[str] | None = None) -> int:
    parser = _parser()
    args = parser.parse_args(argv)
    if args.command is None:
        args = parser.parse_args(["serve"] + ([] if argv is None else argv))
    if args.command == "serve":
        return _serve_command(args)
    if args.command == "lab":
        return _lab_command(args)
    parser.error("unknown command")
    return 2
