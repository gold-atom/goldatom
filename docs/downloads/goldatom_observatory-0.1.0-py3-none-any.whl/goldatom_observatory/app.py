"""Application façade shared by the HTTP server and tests."""

from __future__ import annotations

import copy
from pathlib import Path
from typing import Any

from .events import EventBus
from .journal import JournalTailer


class ObservatoryApplication:
    def __init__(
        self,
        monitor: Any,
        bus: EventBus,
        *,
        journal_path: str | Path | None = None,
        run_action: Any | None = None,
    ) -> None:
        self.monitor = monitor
        self.bus = bus
        self.run_action = run_action
        self.journal = JournalTailer(journal_path, bus) if journal_path else None
        if self.journal is not None:
            self.journal.start()
        if run_action is not None and hasattr(monitor, "set_action_state_provider"):
            monitor.set_action_state_provider(run_action.action_state)

    def get_state(self) -> dict[str, Any]:
        state = self.monitor.get_state()
        if self.journal is not None:
            state["runtime"] = self.journal.snapshot()
            state["negative_checks"].update(state["runtime"].get("negative_checks", {}))
            attempts = state["runtime"].get("attempts")
            if attempts is not None and state.get("atom", {}).get("work"):
                state["atom"]["work"]["attempts"] = attempts
                state["atom"]["work"]["attempts_source"] = "structured lifecycle telemetry"
            self._project_runtime(state)
        else:
            state["runtime"] = {
                "lifecycle_status": "replay" if state["meta"]["mode"] == "replay" else "idle"
            }
        if self.run_action is not None:
            state["actions"].update(self.run_action.action_state())
        state["events"] = self.bus.snapshot()
        return copy.deepcopy(state)


    @staticmethod
    def _project_runtime(state: dict[str, Any]) -> None:
        """Expose in-flight lifecycle telemetry before a portable bundle exists."""

        runtime = state.get("runtime") or {}
        atom = state.get("atom") or {}
        if atom.get("present") or not runtime.get("records"):
            return

        title = runtime.get("last_title")
        detail = runtime.get("last_detail")
        if title:
            atom["status"] = str(title).upper()
        if detail:
            atom["status_detail"] = str(detail)

        stage_order = ["claim", "challenge", "work", "mint", "burial", "title"]
        active = runtime.get("active_stage")
        if active in stage_order:
            active_index = stage_order.index(active)
            for item in state.get("timeline", []):
                stage = item.get("id")
                if stage not in stage_order:
                    continue
                index = stage_order.index(stage)
                item["status"] = (
                    "complete" if index < active_index
                    else "active" if index == active_index
                    else "pending"
                )

        stages = runtime.get("stage_data") or {}

        claim_data = stages.get("claim") or {}
        if claim_data:
            claim = atom.get("claim", {})
            claim.update({
                "height": claim_data.get("height", claim.get("height")),
                "block_hash": claim_data.get("block_hash", claim.get("block_hash")),
                "outpoint": claim_data.get("outpoint", claim.get("outpoint")),
            })
            if claim_data.get("outpoint"):
                claim["state"] = "complete"

        challenge_data = stages.get("challenge") or {}
        if challenge_data:
            challenge = atom.get("challenge", {})
            challenge.update({
                "height": challenge_data.get(
                    "challenge_height", challenge_data.get("height", challenge.get("height"))
                ),
                "block_hash": challenge_data.get("block_hash", challenge.get("block_hash")),
                "digest": challenge_data.get("digest", challenge.get("digest")),
            })
            challenge["state"] = "complete" if challenge_data.get("digest") else "active"

        work_data = stages.get("work") or {}
        if work_data:
            work = atom.get("work", {})
            work.update({
                "expected_hashes": work_data.get("expected_hashes", work.get("expected_hashes")),
                "target": work_data.get("target", work.get("target")),
                "attempts": work_data.get("attempts", work.get("attempts", 0)),
                "hash": work_data.get("work_hash", work.get("hash")),
            })
            work["state"] = "complete" if work_data.get("work_hash") else "active"

        mint_data = stages.get("mint") or {}
        if mint_data:
            mint = atom.get("mint", {})
            mint.update({
                "txid": mint_data.get("txid", mint.get("txid")),
                "commitment": mint_data.get("commitment", mint.get("commitment")),
                "height": mint_data.get("height", mint.get("height")),
                "block_hash": mint_data.get("block_hash", mint.get("block_hash")),
            })
            mint["state"] = "complete" if mint_data.get("height") else "active"
            if mint_data.get("title_outpoint"):
                atom.get("title", {})["outpoint"] = mint_data["title_outpoint"]

        burial_data = stages.get("burial") or {}
        if burial_data:
            burial = atom.get("burial", {})
            burial["required_blocks"] = burial_data.get(
                "required_blocks", burial.get("required_blocks", 1)
            )
            is_complete = bool(burial_data.get("tip_height"))
            burial["blocks"] = burial.get("required_blocks", 1) if is_complete else 0
            burial["state"] = "complete" if is_complete else "active"

        title_data = stages.get("title") or {}
        if title_data:
            if title_data.get("atom_id"):
                atom["atom_id"] = title_data["atom_id"]
            title_record = atom.get("title", {})
            title_record["outpoint"] = title_data.get(
                "current_title", title_record.get("outpoint")
            )
            if title_data.get("current_title"):
                title_record["state"] = "live"

    def get_bundle(self) -> dict[str, Any] | None:
        return self.monitor.get_bundle_dict()

    def action(self, name: str, payload: dict[str, Any] | None = None) -> dict[str, Any]:
        payload = payload or {}
        if name == "verify":
            return {"ok": True, "result": self.monitor.force_verify()}
        if name == "replay":
            reset = getattr(self.monitor, "reset", None)
            if reset is None:
                return {"ok": False, "error": "replay is unavailable in this mode"}
            reset()
            return {"ok": True}
        if name == "speed":
            setter = getattr(self.monitor, "set_speed", None)
            if setter is None:
                return {"ok": False, "error": "speed control is unavailable in this mode"}
            return {"ok": True, "speed": setter(float(payload.get("speed", 1.0)))}
        if name == "run":
            if self.run_action is None:
                return {"ok": False, "error": "fresh regtest creation is unavailable"}
            started = self.run_action.start_lifecycle()
            return {
                "ok": started,
                "error": None if started else "a lifecycle is already running",
                "actions": self.run_action.action_state(),
            }
        return {"ok": False, "error": f"unknown action: {name}"}

    def close(self) -> None:
        if self.journal is not None:
            self.journal.stop()
        self.monitor.stop()
        if self.run_action is not None:
            self.run_action.stop()
