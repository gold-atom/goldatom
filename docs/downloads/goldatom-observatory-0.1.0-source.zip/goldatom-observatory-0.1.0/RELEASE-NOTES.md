# GoldAtom Observatory 0.1.0 — Release Notes

## Delivered

- A complete responsive black-and-gold browser dashboard.
- Truth-labelled recorded-Core replay requiring only Python 3.11+.
- Live read-only Bitcoin Core monitoring and continuous GoldAtom reassay.
- An isolated regtest lab that creates a private node and a fresh GoldAtom lifecycle.
- Structured JSONL lifecycle telemetry merged into a Server-Sent Events stream.
- Six-stage protocol view: claim, challenge, local work, mint, burial, and title.
- Sixteen-gate verifier ledger with local, recorded, and live evidence labels.
- Adversarial display for work mutation, challenge mutation, challenge reorg, and restoration.
- Portable proof JSON drawer and embedded research corpus.
- Source launchers, macOS double-click launchers, Docker replay image, and installable wheel.
- No runtime packages, remote assets, analytics, CDNs, or trackers.

## Validation headline

- 46 automated tests passed.
- One lifecycle started through the site API completed against a private Core node with 16/16 gates and all four adversarial behaviors.
- A second lifecycle completed from the final installed wheel with 16/16 gates, all four negative tests, complete stage telemetry, and clean child-process shutdown, demonstrating that lab mode does not depend on the source-tree script layout.
- SSE framing, action security, package data, replay truth labels, and public-bind refusal were exercised.

## Known boundaries

- The live lab is deliberately regtest-only.
- The included Core provenance comes from a v31.99.0 pre-release build and is labelled accordingly.
- There is no mainnet profile, market, custody layer, final supply curve, or GoldAtom/1 settlement implementation.
- `--unsafe-public` removes the loopback bind refusal but does not add authentication; it should be used only inside an isolated container or trusted network.
- The browser displays verifier output; it is not itself a consensus implementation.

## Recommended first run

```bash
unzip goldatom-observatory-0.1.0-source.zip
cd goldatom-observatory-0.1.0
./start-replay.sh
```

For the actual live experiment:

```bash
BITCOIND=/absolute/path/to/bitcoind ./start-lab.sh
```
