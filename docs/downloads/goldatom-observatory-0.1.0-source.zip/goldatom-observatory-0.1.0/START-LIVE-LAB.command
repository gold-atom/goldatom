#!/bin/sh
set -eu
cd "$(dirname "$0")"
if [ -n "${BITCOIND:-}" ]; then
  BITCOIND_PATH="$BITCOIND"
elif command -v bitcoind >/dev/null 2>&1; then
  BITCOIND_PATH="$(command -v bitcoind)"
elif [ -x /Applications/Bitcoin-Qt.app/Contents/MacOS/bitcoind ]; then
  BITCOIND_PATH=/Applications/Bitcoin-Qt.app/Contents/MacOS/bitcoind
else
  printf '\n%s\n\n' "Bitcoin Core's bitcoind was not found. Install Bitcoin Core, put bitcoind in PATH, or set BITCOIND=/absolute/path/to/bitcoind."
  printf '%s' "Press Return to close: "
  read _unused
  exit 2
fi
exec "${PYTHON_BIN:-python3}" -m goldatom_observatory lab --bitcoind "$BITCOIND_PATH"
