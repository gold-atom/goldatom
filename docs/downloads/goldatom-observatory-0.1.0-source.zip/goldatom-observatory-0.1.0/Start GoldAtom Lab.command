#!/bin/bash
set -e
cd "$(dirname "$0")"
if [[ -n "${BITCOIND:-}" ]]; then
  BIN="$BITCOIND"
elif command -v bitcoind >/dev/null 2>&1; then
  BIN="$(command -v bitcoind)"
elif [[ -x /Applications/Bitcoin-Qt.app/Contents/MacOS/bitcoind ]]; then
  BIN=/Applications/Bitcoin-Qt.app/Contents/MacOS/bitcoind
else
  echo "No bitcoind executable found. Install Bitcoin Core or set BITCOIND=/path/to/bitcoind."
  read -r -p "Press Return to close."
  exit 1
fi
python3 -m goldatom_observatory lab --bitcoind "$BIN"
