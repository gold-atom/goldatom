#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
ARGS=()
if [[ -n "${BITCOIND:-}" ]]; then
  ARGS+=(--bitcoind "$BITCOIND")
fi
exec python3 -m goldatom_observatory lab "${ARGS[@]}" "$@"
