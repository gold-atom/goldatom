# Security and trust boundaries

GoldAtom Observatory 0.1.0 is research software. It has no production or mainnet profile.

## Default boundary

The server binds to `127.0.0.1`. It has no login system because the intended trust boundary is the local machine. Do not expose it directly to an untrusted network.

The `X-GoldAtom-Action: 1` header on POST requests prevents ordinary HTML forms from triggering actions. It is not authentication, authorization, or CSRF protection for a publicly reachable deployment.

## Bitcoin Core access

- Replay mode uses no RPC connection.
- Core mode issues read-only RPC calls for chain, transaction, inclusion, and UTXO verification.
- Lab mode starts a separate node in a newly created private datadir and runs only on `regtest`.
- RPC usernames, passwords, and cookie contents are never sent to the browser.
- Prefer cookie authentication and filesystem permissions over command-line passwords.

## Lab-mode mutations

Lab mode mines valueless regtest blocks, creates valueless regtest transactions, calls `invalidateblock`, and calls `reconsiderblock` against the private node it created. It must never be pointed at a valuable network. The lifecycle runner checks `getblockchaininfo.chain == "regtest"` before proceeding.

## Proof interpretation

A green dashboard means the loaded proof passed the implemented GoldAtom/0 profile against the observed Core state. It does not establish market value, legal title, future finality, absence of implementation defects, or security of a proposed GoldAtom/1 issuance regime.

## Exposure checklist

Before any remote deployment:

1. terminate TLS at a maintained reverse proxy;
2. require strong authentication;
3. firewall Bitcoin RPC so only the server can reach it;
4. use a restricted read-only RPC proxy for monitor mode;
5. disable lab actions or isolate them on a valueless private regtest node;
6. review CSP and response headers after proxying;
7. do not place RPC secrets in URLs, browser storage, or public environment dumps.
