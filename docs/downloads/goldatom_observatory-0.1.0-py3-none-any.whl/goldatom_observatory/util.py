"""Small dependency-free helpers used across the Observatory."""

from __future__ import annotations

import json
import math
import time
from datetime import UTC, datetime
from decimal import Decimal
from pathlib import Path
from typing import Any


def utc_now() -> str:
    return datetime.now(UTC).isoformat(timespec="milliseconds").replace("+00:00", "Z")


def monotonic_ms() -> int:
    return int(time.monotonic() * 1000)


def json_default(value: Any) -> Any:
    if isinstance(value, Decimal):
        return str(value)
    if isinstance(value, Path):
        return str(value)
    raise TypeError(f"cannot encode {type(value).__name__}")


def json_bytes(value: Any, *, pretty: bool = False) -> bytes:
    if pretty:
        text = json.dumps(value, indent=2, sort_keys=True, default=json_default) + "\n"
    else:
        text = json.dumps(value, separators=(",", ":"), default=json_default)
    return text.encode("utf-8")


def load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"), parse_float=Decimal)


def deep_merge(target: dict[str, Any], patch: dict[str, Any]) -> dict[str, Any]:
    for key, value in patch.items():
        if isinstance(value, dict) and isinstance(target.get(key), dict):
            deep_merge(target[key], value)
        else:
            target[key] = value
    return target


def clamp(value: float, low: float = 0.0, high: float = 1.0) -> float:
    return max(low, min(high, value))


def log2_or_zero(value: int | float) -> float:
    return math.log2(value) if value and value > 0 else 0.0


def short_hash(value: str | None, left: int = 8, right: int = 6) -> str:
    if not value:
        return "—"
    if len(value) <= left + right + 1:
        return value
    return f"{value[:left]}…{value[-right:]}"
