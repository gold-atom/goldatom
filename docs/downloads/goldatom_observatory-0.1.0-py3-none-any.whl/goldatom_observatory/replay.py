"""Truthfully labelled replay of the preserved 2026-09-02 Bitcoin Core run."""

from __future__ import annotations

import copy
import hashlib
import threading
import time
from dataclasses import dataclass
from typing import Any

from goldatom.models import GoldAtomBundle

from .diagnostics import offline_checks, offline_facts
from .events import EventBus
from .evidence import Evidence
from .util import clamp, deep_merge, utc_now


@dataclass(frozen=True, slots=True)
class ReplayPhase:
    at: float
    kind: str
    message: str
    level: str
    stage: str | None
    patch: dict[str, Any]
    data: dict[str, Any]


class ReplayMonitor:
    """Replays recorded evidence without pretending it is a current live node."""

    mode = "replay"

    def __init__(self, bus: EventBus, *, speed: float = 1.0, auto_start: bool = True) -> None:
        self.bus = bus
        self.evidence = Evidence.load()
        self.bundle = GoldAtomBundle.from_dict(self.evidence.bundle)
        self.facts = offline_facts(self.bundle)
        self._lock = threading.RLock()
        self._stop = threading.Event()
        self._wake = threading.Event()
        self._thread: threading.Thread | None = None
        self._speed = max(0.25, min(float(speed), 8.0))
        self._started_at = time.monotonic()
        self._phase_index = -1
        self._generation = 0
        self._state = self._initial_state()
        self._phases = self._build_phases()
        if auto_start:
            self.start()

    def _initial_state(self) -> dict[str, Any]:
        bundle = self.bundle
        summary = self.evidence.summary
        version = summary.get("version_first_line", "Bitcoin Core validation evidence")
        return {
            "meta": {
                "name": "GOLDATOM OBSERVATORY",
                "version": "0.1.0",
                "mode": "replay",
                "mode_label": "RECORDED CORE REPLAY",
                "connected": True,
                "live": False,
                "truth_label": "Replay of preserved Bitcoin Core regtest evidence from 2026-09-02.",
                "started_at": utc_now(),
                "updated_at": utc_now(),
                "generation": self._generation,
                "speed": self._speed,
            },
            "node": {
                "chain": "regtest",
                "height": 0,
                "headers": 0,
                "tip_hash": None,
                "chainwork": "0" * 64,
                "difficulty": "4.656542373906925E-10",
                "verification_progress": 0.0,
                "connections": 0,
                "mempool_txs": 0,
                "size_on_disk": 0,
                "rpc_latency_ms": None,
                "subversion": version,
                "warning": summary.get("warning"),
            },
            "atom": {
                "present": False,
                "valid": None,
                "status": "NODE BOOT",
                "status_detail": "Loading the preserved regtest lifecycle.",
                "profile": bundle.profile,
                "atom_id": None,
                "claim": {
                    "height": bundle.claim.height,
                    "outpoint": str(bundle.claim.outpoint),
                    "block_hash": bundle.claim.block_hash,
                    "commitment": bundle.claim.commitment_hex,
                    "state": "pending",
                },
                "challenge": {
                    "height": bundle.work.challenge_height,
                    "block_hash": bundle.work.challenge_block_hash,
                    "digest": bundle.work.challenge_digest_hex,
                    "state": "pending",
                },
                "work": {
                    "algorithm": bundle.claim.algorithm,
                    "target": bundle.claim.target_hex,
                    "hash": bundle.work.work_hash_hex,
                    "expected_hashes": self.facts["expected_hashes"],
                    "expected_work_log2": self.facts["expected_work_log2"],
                    "attempts": 0,
                    "final_attempts": self.facts["attempts"],
                    "state": "pending",
                },
                "mint": {
                    "height": bundle.mint.height,
                    "txid": bundle.mint.txid,
                    "block_hash": bundle.mint.block_hash,
                    "commitment": bundle.mint.commitment_hex,
                    "state": "pending",
                },
                "burial": {
                    "blocks": 0,
                    "chainwork": "0",
                    "required_blocks": 1,
                    "state": "pending",
                },
                "title": {
                    "outpoint": f"{bundle.mint.txid}:{bundle.mint.title_vout}",
                    "script_hex": bundle.mint.title_script_hex,
                    "script_type": "witness_v1_taproot",
                    "address": self.evidence.consensus.get("terminal_utxo", {})
                    .get("scriptPubKey", {})
                    .get("address"),
                    "value_sats": 98_000,
                    "confirmations": 0,
                    "unspent": None,
                    "state": "pending",
                },
            },
            "timeline": self._timeline(-1),
            "checks": offline_checks(self.bundle, recorded_pass=False),
            "blocks": [],
            "negative_checks": {
                "tampered_work_rejected": None,
                "tampered_challenge_rejected": None,
                "challenge_reorg_rejected": None,
                "reconsider_restored_validity": None,
            },
            "actions": {
                "can_replay": True,
                "can_verify": True,
                "can_run": False,
                "running": False,
            },
            "documents": Evidence.documents(),
        }

    def _timeline(self, phase_index: int) -> list[dict[str, Any]]:
        stages = [
            ("claim", "CLAIM", 2),
            ("challenge", "CHALLENGE", 5),
            ("work", "LOCAL WORK", 7),
            ("mint", "MINT", 9),
            ("burial", "BURIAL", 10),
            ("title", "TITLE", 11),
        ]
        current_stage = {
            0: None,
            1: "claim",
            2: "claim",
            3: "challenge",
            4: "challenge",
            5: "challenge",
            6: "work",
            7: "work",
            8: "mint",
            9: "mint",
            10: "burial",
            11: "title",
            12: "title",
            13: "title",
            14: "challenge",
            15: "title",
        }.get(phase_index, "title" if phase_index > 15 else None)
        result = []
        for stage_id, label, complete_at in stages:
            if phase_index >= complete_at:
                status = "complete"
            elif stage_id == current_stage:
                status = "active"
            else:
                status = "pending"
            if phase_index == 14 and stage_id in {"challenge", "work", "mint", "burial", "title"}:
                status = "invalid" if stage_id == "challenge" else "blocked"
            result.append({"id": stage_id, "label": label, "status": status})
        return result

    def _known_hash(self, height: int) -> str | None:
        headers = self.evidence.provenance["atom"]["block_headers"]
        by_height = {int(record["height"]): record["hash"] for record in headers.values()}
        return by_height.get(height)

    def _blocks_through(self, height: int, *, invalidated_from: int | None = None) -> list[dict[str, Any]]:
        if height <= 0:
            return []
        roles = {
            self.bundle.claim.height: "claim",
            self.bundle.work.challenge_height: "challenge",
            self.bundle.mint.height: "mint",
            107: "burial",
        }
        start = max(101, height - 10)
        blocks: list[dict[str, Any]] = []
        for block_height in range(start, height + 1):
            digest = self._known_hash(block_height)
            if digest is None:
                digest = hashlib.sha256(f"recorded-regtest:{block_height}".encode()).hexdigest()
            role = roles.get(block_height, "bitcoin")
            canonical = invalidated_from is None or block_height < invalidated_from
            blocks.append(
                {
                    "height": block_height,
                    "hash": digest,
                    "role": role,
                    "canonical": canonical,
                    "confirmations": max(0, height - block_height + 1) if canonical else 0,
                    "chainwork": str(block_height * 2),
                    "recorded": True,
                }
            )
        return blocks

    def _base_patch_for_height(self, height: int) -> dict[str, Any]:
        tip_hash = self._known_hash(height)
        if tip_hash is None:
            tip_hash = hashlib.sha256(f"recorded-regtest:{height}".encode()).hexdigest()
        return {
            "node": {
                "height": height,
                "headers": height,
                "tip_hash": tip_hash,
                "chainwork": f"{height * 2:064x}",
                "verification_progress": 1.0,
                "size_on_disk": int(33_896 * clamp(height / 107)),
            },
            "blocks": self._blocks_through(height),
        }

    def _build_phases(self) -> tuple[ReplayPhase, ...]:
        bundle = self.bundle
        atom_id = self.evidence.baseline["atom_id"]
        final_checks = offline_checks(bundle, recorded_pass=True)
        return (
            ReplayPhase(
                0.0,
                "replay.started",
                "Preserved Bitcoin Core evidence mounted; replay clock started.",
                "signal",
                None,
                {
                    "atom": {
                        "status": "NODE BOOT",
                        "status_detail": "Starting at the beginning of the recorded regtest lifecycle.",
                    }
                },
                {},
            ),
            ReplayPhase(
                1.1,
                "node.ready",
                "Regtest node reached a mature wallet state at height 101.",
                "info",
                "claim",
                deep_merge(
                    self._base_patch_for_height(101),
                    {
                        "atom": {
                            "status": "CLAIM FORMATION",
                            "status_detail": "A spendable single-use claim seal is being constructed.",
                        }
                    },
                ),
                {"height": 101},
            ),
            ReplayPhase(
                2.6,
                "claim.confirmed",
                f"Claim seal confirmed at height {bundle.claim.height}.",
                "success",
                "claim",
                deep_merge(
                    self._base_patch_for_height(bundle.claim.height),
                    {
                        "atom": {
                            "present": True,
                            "status": "CLAIM CONFIRMED",
                            "status_detail": "The target and work algorithm are now fixed before the future challenge exists.",
                            "claim": {"state": "complete"},
                        }
                    },
                ),
                {"height": bundle.claim.height, "outpoint": str(bundle.claim.outpoint)},
            ),
            ReplayPhase(
                4.0,
                "block.connected",
                "Intervening Bitcoin block 103 connected.",
                "info",
                "challenge",
                deep_merge(
                    self._base_patch_for_height(103),
                    {
                        "atom": {
                            "status": "WAITING FOR FUTURE HISTORY",
                            "status_detail": "Two of three challenge-delay blocks are now fixed.",
                            "challenge": {"state": "waiting"},
                        }
                    },
                ),
                {"height": 103},
            ),
            ReplayPhase(
                5.1,
                "block.connected",
                "Intervening Bitcoin block 104 connected.",
                "info",
                "challenge",
                deep_merge(
                    self._base_patch_for_height(104),
                    {
                        "atom": {
                            "status": "WAITING FOR FUTURE HISTORY",
                            "status_detail": "One block remains before the challenge is unknowably fixed.",
                        }
                    },
                ),
                {"height": 104},
            ),
            ReplayPhase(
                6.4,
                "challenge.locked",
                f"Challenge fixed by canonical block {bundle.work.challenge_height}.",
                "signal",
                "challenge",
                deep_merge(
                    self._base_patch_for_height(bundle.work.challenge_height),
                    {
                        "atom": {
                            "status": "CHALLENGE LOCKED",
                            "status_detail": "The claimant can no longer choose the historical input to the work problem.",
                            "challenge": {"state": "complete"},
                        }
                    },
                ),
                {"height": bundle.work.challenge_height, "block_hash": bundle.work.challenge_block_hash},
            ),
            ReplayPhase(
                7.5,
                "work.started",
                "Searching the 80-byte SHA-256d work space.",
                "warning",
                "work",
                {
                    "atom": {
                        "status": "EXTRACTING DIGITAL ORE",
                        "status_detail": "Exclusive local work is now competing against the committed target.",
                        "work": {"state": "active", "attempts": 1},
                    }
                },
                {"algorithm": bundle.claim.algorithm, "target": bundle.claim.target_hex},
            ),
            ReplayPhase(
                9.1,
                "work.found",
                f"Valid local proof found after {self.facts['attempts']} attempts.",
                "success",
                "work",
                {
                    "atom": {
                        "status": "WORK FOUND",
                        "status_detail": "The below-target hash is exclusive to this claim and challenge.",
                        "work": {"state": "complete", "attempts": self.facts["attempts"]},
                    }
                },
                {"attempts": self.facts["attempts"], "work_hash": bundle.work.work_hash_hex},
            ),
            ReplayPhase(
                10.4,
                "mint.broadcast",
                "Mint transaction accepted into the regtest mempool.",
                "info",
                "mint",
                {
                    "node": {"mempool_txs": 1},
                    "atom": {
                        "status": "MINT IN MEMPOOL",
                        "status_detail": "The claim seal is being consumed into one title output.",
                        "mint": {"state": "broadcast"},
                    },
                },
                {"txid": bundle.mint.txid},
            ),
            ReplayPhase(
                11.8,
                "mint.confirmed",
                f"Mint and title seal confirmed at height {bundle.mint.height}.",
                "success",
                "mint",
                deep_merge(
                    self._base_patch_for_height(bundle.mint.height),
                    {
                        "node": {"mempool_txs": 0},
                        "atom": {
                            "atom_id": atom_id,
                            "status": "ATOM BORN",
                            "status_detail": "One immutable work proof now has one Bitcoin title seal.",
                            "mint": {"state": "complete"},
                            "title": {"state": "confirmed", "confirmations": 1, "unspent": True},
                        },
                    },
                ),
                {"height": bundle.mint.height, "txid": bundle.mint.txid, "atom_id": atom_id},
            ),
            ReplayPhase(
                13.2,
                "burial.complete",
                "One post-mint Bitcoin block supplied the required burial.",
                "success",
                "burial",
                deep_merge(
                    self._base_patch_for_height(107),
                    {
                        "atom": {
                            "status": "PROOF BURIED",
                            "status_detail": "The mint is now protected by subsequent canonical chainwork.",
                            "burial": {"state": "complete", "blocks": 1, "chainwork": "2"},
                            "title": {"state": "live", "confirmations": 2, "unspent": True},
                        }
                    },
                ),
                {"burial_blocks": 1, "burial_chainwork": "2"},
            ),
            ReplayPhase(
                14.5,
                "verification.pass",
                "Independent GoldAtom verifier accepted every normative gate.",
                "success",
                "title",
                {
                    "atom": {
                        "valid": True,
                        "status": "VALID GOLDATOM / 0",
                        "status_detail": "Local work, Bitcoin publication, burial, and terminal title all verify.",
                    },
                    "checks": final_checks,
                },
                {"atom_id": atom_id},
            ),
            ReplayPhase(
                16.0,
                "tamper.rejected",
                "A one-nibble work-hash mutation was rejected with BAD_WORK_HASH.",
                "warning",
                "work",
                {"negative_checks": {"tampered_work_rejected": True}},
                {"code": "BAD_WORK_HASH"},
            ),
            ReplayPhase(
                17.1,
                "tamper.rejected",
                "A one-nibble challenge mutation was rejected with BAD_CHALLENGE.",
                "warning",
                "challenge",
                {"negative_checks": {"tampered_challenge_rejected": True}},
                {"code": "BAD_CHALLENGE"},
            ),
            ReplayPhase(
                18.5,
                "reorg.invalidated",
                "The challenge block was invalidated; the atom immediately ceased to verify.",
                "error",
                "challenge",
                {
                    "node": {
                        "height": 104,
                        "headers": 107,
                        "tip_hash": self._known_hash(104)
                        or hashlib.sha256(b"recorded-regtest:104").hexdigest(),
                        "chainwork": f"{104 * 2:064x}",
                    },
                    "blocks": self._blocks_through(107, invalidated_from=105),
                    "atom": {
                        "valid": False,
                        "status": "HISTORY WITHDRAWN",
                        "status_detail": "Canonical challenge history is absent; dependent work and title are blocked.",
                        "challenge": {"state": "invalid"},
                        "work": {"state": "blocked"},
                        "mint": {"state": "blocked"},
                        "burial": {"state": "blocked"},
                        "title": {"state": "blocked", "confirmations": 0, "unspent": None},
                    },
                    "negative_checks": {"challenge_reorg_rejected": True},
                },
                {"invalidated_height": 105, "new_tip_height": 104},
            ),
            ReplayPhase(
                20.2,
                "reorg.restored",
                "The block was reconsidered; canonical history and atom validity returned.",
                "success",
                "title",
                deep_merge(
                    self._base_patch_for_height(107),
                    {
                        "atom": {
                            "valid": True,
                            "status": "VALIDITY RESTORED",
                            "status_detail": "The same proof object verifies again because its committed history is canonical.",
                            "challenge": {"state": "complete"},
                            "work": {"state": "complete", "attempts": self.facts["attempts"]},
                            "mint": {"state": "complete"},
                            "burial": {"state": "complete", "blocks": 1, "chainwork": "2"},
                            "title": {"state": "live", "confirmations": 2, "unspent": True},
                        },
                        "checks": final_checks,
                        "negative_checks": {"reconsider_restored_validity": True},
                    },
                ),
                {"tip_height": 107, "atom_id": atom_id},
            ),
        )

    def start(self) -> None:
        with self._lock:
            if self._thread and self._thread.is_alive():
                return
            self._thread = threading.Thread(target=self._run, name="goldatom-replay", daemon=True)
            self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        self._wake.set()
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=2.0)

    def _run(self) -> None:
        while not self._stop.is_set():
            self.tick()
            self._wake.wait(0.08)
            self._wake.clear()

    def tick(self) -> None:
        with self._lock:
            elapsed = (time.monotonic() - self._started_at) * self._speed
            while self._phase_index + 1 < len(self._phases):
                next_phase = self._phases[self._phase_index + 1]
                if next_phase.at > elapsed:
                    break
                self._phase_index += 1
                deep_merge(self._state, copy.deepcopy(next_phase.patch))
                self._state["timeline"] = self._timeline(self._phase_index)
                self._state["meta"]["updated_at"] = utc_now()
                self._state["meta"]["generation"] = self._generation
                self.bus.publish(
                    next_phase.kind,
                    next_phase.message,
                    level=next_phase.level,
                    stage=next_phase.stage,
                    data=next_phase.data,
                )

    def get_state(self) -> dict[str, Any]:
        self.tick()
        with self._lock:
            state = copy.deepcopy(self._state)
            total = self._phases[-1].at if self._phases else 1.0
            elapsed = (time.monotonic() - self._started_at) * self._speed
            state["meta"]["replay_progress"] = clamp(elapsed / total)
            state["meta"]["replay_complete"] = self._phase_index >= len(self._phases) - 1
            state["events"] = self.bus.snapshot()
            return state

    def get_bundle_dict(self) -> dict[str, Any]:
        return self.bundle.to_dict()

    def reset(self) -> None:
        with self._lock:
            self._generation += 1
            self._phase_index = -1
            self._started_at = time.monotonic()
            self._state = self._initial_state()
            self._state["meta"]["generation"] = self._generation
            self.bus.publish(
                "replay.reset",
                "Replay reset to the beginning of the preserved Core lifecycle.",
                level="signal",
                data={"generation": self._generation},
            )
            self._wake.set()

    def set_speed(self, speed: float) -> float:
        speed = max(0.25, min(float(speed), 8.0))
        with self._lock:
            elapsed_replay = (time.monotonic() - self._started_at) * self._speed
            self._speed = speed
            self._started_at = time.monotonic() - elapsed_replay / speed
            self._state["meta"]["speed"] = speed
            self.bus.publish(
                "replay.speed",
                f"Replay speed set to {speed:g}×.",
                level="info",
                data={"speed": speed},
            )
            self._wake.set()
            return speed

    def force_verify(self) -> dict[str, Any]:
        with self._lock:
            facts = offline_facts(self.bundle)
            all_local = all(
                facts[key]
                for key in (
                    "claim_commitment_recomputes",
                    "challenge_recomputes",
                    "work_hash_recomputes",
                    "work_satisfies_target",
                    "mint_commitment_recomputes",
                )
            )
            self.bus.publish(
                "verification.local",
                "Pure protocol commitments recomputed locally; canonicality remains recorded evidence.",
                level="success" if all_local else "error",
                stage="title",
                data={"local_valid": all_local},
            )
            return {"local_valid": all_local, "facts": facts}
