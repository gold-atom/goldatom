"""Access to bundled GoldAtom/0 validation evidence and research documents."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

from .util import load_json


PACKAGE_ROOT = Path(__file__).resolve().parent
DATA_ROOT = PACKAGE_ROOT / "data"
EVIDENCE_ROOT = DATA_ROOT / "evidence"
DOCUMENT_ROOT = DATA_ROOT / "documents"


@dataclass(frozen=True, slots=True)
class Evidence:
    bundle: dict[str, Any]
    provenance: dict[str, Any]
    summary: dict[str, Any]
    baseline: dict[str, Any]
    consensus: dict[str, Any]
    negative: dict[str, Any]

    @classmethod
    def load(cls) -> "Evidence":
        return cls(
            bundle=load_json(EVIDENCE_ROOT / "live-core-final.goldatom.json"),
            provenance=load_json(EVIDENCE_ROOT / "provenance.json"),
            summary=load_json(EVIDENCE_ROOT / "summary.json"),
            baseline=load_json(EVIDENCE_ROOT / "verify-baseline.json"),
            consensus=load_json(EVIDENCE_ROOT / "consensus-primitives.json"),
            negative=load_json(EVIDENCE_ROOT / "negative-results.json"),
        )

    @staticmethod
    def documents() -> list[dict[str, str]]:
        descriptions = {
            "SPEC-0.md": "Normative GoldAtom/0 object protocol.",
            "SPEC-1-CANDIDATE.md": "Canonical-vein issuance candidate for GoldAtom/1.",
            "THREAT-MODEL.md": "Failure criteria, attack surfaces, and mitigations.",
            "ISSUANCE-SIMULATION.md": "Adversarial comparison of issuance regimes.",
            "VALIDATION.md": "Executed checks and remaining validation gaps.",
            "FINAL-VALIDATION-TRANSCRIPT.md": "Complete Bitcoin Core run and negative-test transcript.",
            "OBSERVATORY-VALIDATION.md": "Website, API, packaging, and isolated live-lab validation record.",
            "OBSERVATORY-LIVE-TRANSCRIPT.md": "Structured transcript of a lifecycle started and observed through the site.",
            "OBSERVATORY-BUILD-TRANSCRIPT.md": "Architecture, live-run, adversarial, security, and packaging transcript.",
        }
        result: list[dict[str, str]] = []
        for path in sorted(DOCUMENT_ROOT.glob("*.md")):
            result.append(
                {
                    "name": path.name,
                    "title": path.stem.replace("-", " "),
                    "description": descriptions.get(path.name, "GoldAtom research document."),
                    "url": f"/docs/{path.name}",
                    "download_url": f"/download/documents/{path.name}",
                }
            )
        return result
