# GoldAtom Observatory 0.1.0 — Validation Record

Date: 2026-09-02 UTC  
Scope: website, replay engine, HTTP/SSE surface, verifier projection, isolated Bitcoin Core regtest lab, lifecycle journal, and packaging.

## Result

The Observatory successfully started a private Bitcoin Core regtest node, accepted a lifecycle request through its own HTTP action surface, displayed the structured event stream, and continuously reassayed the resulting proof bundle.

Final observed object:

```text
Atom ID:                  6444e4843b5c8c4af3bdfb2a763e7e3fd41542fd890a4572d4c9c89057fe109d
Profile:                  goldatom-regtest-v0
Claim height:             102
Challenge height:         105
Mint height:              106
Assay tip:                107
Local work attempts:      15
Expected local hashes:    16
Bitcoin burial blocks:    1
Bitcoin burial chainwork: 2
Current title:            c2d97bf3c716154e55d9e096fb85827d8c92f3561dd8ffb7be690865148bb8ae:0
Normative checks:         16 / 16 pass
Lifecycle exit code:      0
```

The site action response reported `running=true`, then the final site state reported `running=false`, `last_exit_code=0`, `valid=true`, and all four adversarial signals true.

## Executed lifecycle

```text
private Core node
  → 101 maturity blocks
  → claim broadcast and confirmation at 102
  → future blocks 103, 104, 105
  → challenge fixed at 105
  → local proof found after 15 attempts
  → mint broadcast and confirmation at 106
  → post-mint burial at 107
  → portable proof written
  → 16-gate independent verification passed
  → work-hash mutation rejected
  → challenge mutation rejected
  → challenge block invalidated
  → proof ceased to verify
  → canonical history reconsidered
  → unchanged proof became valid again
```

## Negative tests observed through telemetry

| Attack | Required behavior | Result |
|---|---|---|
| Mutate the work hash | Stop at `BAD_WORK_HASH` | Pass |
| Mutate the challenge digest | Stop at `BAD_CHALLENGE` | Pass |
| Invalidate the challenge block | Reject the proof as noncanonical | Pass |
| Restore committed history | Accept the unchanged proof again | Pass |

## Node provenance

```text
Bitcoin Core daemon version v31.99.0-031175197f1b bitcoind
SHA-256: 8e3afd78738ebc6d59787fc232c4f0025b6a3dd1e2c59cee4fd1b5ed1ba3dba4
Network: regtest
P2P listening: disabled
RPC authentication: private cookie
```

This binary is a pre-release Core build, not a signed release binary. That limitation is displayed by the site through the node warning and remains a provenance caveat, not silently erased.

## Site/API checks

- `/` returned the complete application and security headers.
- `/api/health` returned connected live-Core state.
- `/api/state` returned the coherent node, atom, checks, timeline, actions, runtime, and event projection.
- `/api/bundle` returned the portable proof object.
- `/api/events` produced a timed streaming sample with `retry`, monotonic `id`, `event: observatory`, and JSON `data` frames; reconnect support uses `Last-Event-ID`.
- POST actions without `X-GoldAtom-Action: 1` were rejected.
- The `run` action started the lifecycle from the same API used by the browser button.
- The `verify` action forced a fresh verifier pass.
- Public-interface binding is refused unless `--unsafe-public` is explicitly supplied.

## Browser/UI validation

The delivered desktop previews were rendered from the real application in both modes:

- `docs/replay-preview.png` — preserved Core replay, explicitly labelled recorded.
- `docs/live-preview.png` — direct live-Core assay and fresh regtest lifecycle.

The JavaScript passed Node syntax checking. The UI contains no remote scripts, fonts, analytics, trackers, CDNs, or third-party network dependencies.

## Automated suite

The release runs the inherited GoldAtom protocol/RPC/economics tests plus Observatory-specific tests covering:

- bundled evidence integrity and local protocol recomputation;
- event sequencing;
- journal durability and projection;
- replay source labelling, restart, speed control, and local reassay;
- HTTP state, bundle, health, security headers, and action controls;
- loopback bind policy;
- bitcoind discovery and private run-directory allocation.

The automated suite passed **46 tests**. The wheel then installed into a new virtual environment with no runtime dependencies. From that installed wheel:

- replay mode served and returned healthy state;
- all eight research documents and preserved proof data were present;
- the isolated live lab started a fresh Core node;
- a new atom `7edc1f7294bec470850c556a2eaf5d6a5ee852f8963cb18cf719047cc2cf1af6` completed with 16/16 verifier checks, all four adversarial signals, exit code 0, persistent telemetry for all seven stages, and a clean shutdown of its private Core child.

Exact outputs are preserved in `validation/test-suite-final.log`, `validation/static-validation-final.log`, and `validation/wheel-final-validation.log`.

## Sanitization

The included `validation/observatory-live-lab/` directory contains only the portable proof, structured journal, version/hash records, lifecycle console output, and final projected state. It deliberately excludes:

- the Bitcoin datadir;
- the RPC cookie;
- wallet databases;
- private keys;
- chainstate and block files.

## Interpretation boundary

This validates the Observatory as an interface and the GoldAtom/0 lifecycle as a regtest proof object. It does **not** validate a mainnet monetary regime, establish market value, demonstrate energy provenance, or settle GoldAtom/1 issuance economics.
