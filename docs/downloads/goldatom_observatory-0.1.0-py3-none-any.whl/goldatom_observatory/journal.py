"""Append-only JSONL event journal shared by lifecycle scripts and the observatory."""

from __future__ import annotations

import json
import os
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


class JournalWriter:
    """Small, crash-tolerant JSONL writer.

    Every call opens the file in append mode, writes one compact JSON object, flushes,
    and fsyncs. The lifecycle is low-volume, so durability and tailability matter more
    than throughput.
    """

    def __init__(self, path: str | Path | None):
        self.path = Path(path).expanduser().resolve() if path else None
        self._lock = threading.Lock()
        if self.path is not None:
            self.path.parent.mkdir(parents=True, exist_ok=True)

    def emit(
        self,
        kind: str,
        title: str,
        detail: str = "",
        *,
        severity: str = "info",
        **data: Any,
    ) -> None:
        if self.path is None:
            return
        record = {
            "ts": datetime.now(timezone.utc).isoformat(),
            "kind": kind,
            "severity": severity,
            "title": title,
            "detail": detail,
            "data": data,
        }
        encoded = json.dumps(record, sort_keys=True, separators=(",", ":"), default=str)
        with self._lock:
            with self.path.open("a", encoding="utf-8") as handle:
                handle.write(encoded + "\n")
                handle.flush()
                os.fsync(handle.fileno())


class JournalTailer:
    """Tail a JournalWriter file and project records into an Observatory EventBus."""

    def __init__(self, path: str | Path, bus: Any, *, poll_interval: float = 0.15):
        self.path = Path(path).expanduser().resolve()
        self.bus = bus
        self.poll_interval = max(0.05, float(poll_interval))
        self._offset = 0
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self._lock = threading.Lock()
        self._summary: dict[str, Any] = {
            "path": str(self.path),
            "records": 0,
            "last_kind": None,
            "last_title": None,
            "last_detail": None,
            "last_data": {},
            "active_stage": None,
            "stage_data": {
                "node": {},
                "claim": {},
                "challenge": {},
                "work": {},
                "mint": {},
                "burial": {},
                "title": {},
            },
            "attempts": None,
            "lifecycle_status": "idle",
            "negative_checks": {
                "tampered_work_rejected": None,
                "tampered_challenge_rejected": None,
                "challenge_reorg_rejected": None,
                "reconsider_restored_validity": None,
            },
        }

    def start(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._thread = threading.Thread(target=self._run, name="goldatom-journal", daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=2.0)

    def _run(self) -> None:
        while not self._stop.is_set():
            self.poll()
            self._stop.wait(self.poll_interval)

    def poll(self) -> None:
        if not self.path.exists():
            return
        size = self.path.stat().st_size
        if size < self._offset:
            self._offset = 0
        with self.path.open("r", encoding="utf-8") as handle:
            handle.seek(self._offset)
            while True:
                line = handle.readline()
                if not line:
                    break
                self._offset = handle.tell()
                try:
                    record = json.loads(line)
                except json.JSONDecodeError:
                    continue
                self._consume(record)

    def _consume(self, record: dict[str, Any]) -> None:
        kind = str(record.get("kind") or "journal.event")
        title = str(record.get("title") or kind)
        detail = str(record.get("detail") or "")
        severity = str(record.get("severity") or "info")
        if severity not in {"info", "success", "warning", "error", "signal"}:
            severity = "info"
        data = record.get("data") if isinstance(record.get("data"), dict) else {}
        stage = data.get("stage") if isinstance(data.get("stage"), str) else None
        event_data = dict(data)
        event_data.pop("stage", None)
        if detail:
            event_data["detail"] = detail
        self.bus.publish(
            kind,
            title,
            level=severity,
            stage=stage,
            data=event_data,
            timestamp=str(record.get("ts") or datetime.now(timezone.utc).isoformat()),
        )
        with self._lock:
            if kind == "lifecycle.started":
                self._summary["stage_data"] = {
                    "node": {},
                    "claim": {},
                    "challenge": {},
                    "work": {},
                    "mint": {},
                    "burial": {},
                    "title": {},
                }
                self._summary["attempts"] = None
                self._summary["negative_checks"] = {
                    "tampered_work_rejected": None,
                    "tampered_challenge_rejected": None,
                    "challenge_reorg_rejected": None,
                    "reconsider_restored_validity": None,
                }
            self._summary["records"] += 1
            self._summary["last_kind"] = kind
            self._summary["last_title"] = title
            self._summary["last_detail"] = detail
            self._summary["last_data"] = dict(data)
            self._summary["active_stage"] = stage
            if stage in self._summary["stage_data"]:
                self._summary["stage_data"][stage].update(data)
            if "attempts" in data:
                self._summary["attempts"] = data["attempts"]
            if kind == "lifecycle.started":
                self._summary["lifecycle_status"] = "running"
            elif kind == "lifecycle.complete":
                self._summary["lifecycle_status"] = "complete"
            elif kind == "lifecycle.failed":
                self._summary["lifecycle_status"] = "failed"
            negative = self._summary["negative_checks"]
            if kind == "tamper.work.rejected":
                negative["tampered_work_rejected"] = True
            elif kind == "tamper.challenge.rejected":
                negative["tampered_challenge_rejected"] = True
            elif kind == "reorg.rejected":
                negative["challenge_reorg_rejected"] = True
            elif kind == "reorg.restored":
                negative["reconsider_restored_validity"] = True

    def snapshot(self) -> dict[str, Any]:
        with self._lock:
            result = dict(self._summary)
            result["last_data"] = dict(self._summary["last_data"])
            result["stage_data"] = {
                key: dict(value) for key, value in self._summary["stage_data"].items()
            }
            result["negative_checks"] = dict(self._summary["negative_checks"])
            return result
