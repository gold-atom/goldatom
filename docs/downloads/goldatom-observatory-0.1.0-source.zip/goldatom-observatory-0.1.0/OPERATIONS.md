# Observatory Operations Guide

## Fastest start

From the extracted release directory:

```bash
./start-replay.sh
```

The replay is the preserved, truth-labelled Bitcoin Core lifecycle. It is useful for reviewing the protocol without installing or trusting a node.

## Live lab prerequisites

- Python 3.11 or newer.
- A `bitcoind` executable.
- No Bitcoin funds, network connection, or pre-existing datadir are required.

The lab invokes Bitcoin Core with `-regtest`, `-listen=0`, a fresh datadir, a dynamically selected RPC port, and cookie authentication. Its test coins have no mainnet value.

```bash
BITCOIND=/absolute/path/to/bitcoind ./start-lab.sh
```

Or:

```bash
python3 -m goldatom_observatory lab --bitcoind /absolute/path/to/bitcoind
```

## Reading the evidence labels

- **PASS · local recomputation** means the fact can be recomputed solely from the portable proof object.
- **RECORDED · Core validation** means the fact depended on the preserved Bitcoin Core run and is being replayed, not presently queried.
- **PASS · live verifier** means the current node supplied the active-chain evidence and the verifier accepted it now.
- **FAIL** identifies the first rejected normative gate; later gates are marked blocked.

Bitcoin burial and GoldAtom-local work are deliberately displayed separately. Bitcoin chainwork is shared historical security. It is not counted as exclusive material content in every atom.

## HTTP surface

| Route | Method | Purpose |
|---|---:|---|
| `/` | GET | Dashboard |
| `/api/state` | GET | Complete current projection |
| `/api/bundle` | GET | Loaded portable proof JSON |
| `/api/events` | GET | Server-Sent Events stream |
| `/api/health` | GET | Connectivity and update status |
| `/api/action/verify` | POST | Force a reassay |
| `/api/action/replay` | POST | Restart replay |
| `/api/action/speed` | POST | Change replay speed |
| `/api/action/run` | POST | Start a fresh isolated lab lifecycle |

POST actions require `X-GoldAtom-Action: 1`. This is a local-action/CSRF barrier, not user authentication. Keep the default loopback binding.

## Run artifacts

Each lab start creates a new directory like:

```text
goldatom-runs/lab-20260902T070122Z/
├── atom-0001.goldatom.json
├── bitcoind-version.txt
├── bitcoind.sha256
├── bitcoind.stdout.log
├── bitcoind.stderr.log
├── events.jsonl
├── lifecycle-0001.stdout.log
├── lifecycle-0001.stderr.log
└── node/                         # private local datadir; never publish wholesale
```

The portable proof, events, version, hashes, and lifecycle logs are suitable for a sanitized validation archive. Do **not** publish `node/`: it contains the RPC cookie and wallet material.

## Existing Core attachment

The live monitor supports Bitcoin Core cookie or username/password authentication. It only uses read-only chain, network, mempool, transaction-proof, and UTXO calls. The configured proof bundle is reloaded when its modification time changes.

The expected profile is currently `goldatom-regtest-v0`; a wrong network is rejected by the verifier.

## Shutdown

Press `Ctrl-C` in the terminal. In lab mode, the Observatory asks Core to stop cleanly; if RPC shutdown fails, it terminates the private process. Run files remain on disk for inspection.
