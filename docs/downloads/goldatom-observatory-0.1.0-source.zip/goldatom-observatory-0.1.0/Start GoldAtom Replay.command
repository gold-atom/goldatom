#!/bin/bash
set -e
cd "$(dirname "$0")"
python3 -m goldatom_observatory serve --mode replay
