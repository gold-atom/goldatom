# GoldAtom Observatory 0.1.0

A local-first live instrument for **GoldAtom/0 Proof-Buried Work**.

The Observatory makes the entire experimental object lifecycle visible:

```text
claim seal
  → future Bitcoin challenge
  → atom-specific SHA-256d work
  → mint transaction
  → post-mint chainwork burial
  → live title UTXO
  → independent assay
  → tamper attacks
  → challenge-block reorganization
  → restoration
```

![GoldAtom Observatory live Core mode](docs/goldatom-observatory-live.png)

GoldAtom/0 is an experimental client-validated digital object protocol. It uses Bitcoin for publication, ordering, reorganization resistance, and title. It **does not** define a production monetary issuance schedule, a mainnet profile, or an investment product.

## What the site shows

- live Bitcoin Core tip, recent blocks, chainwork, RPC latency, peer count, mempool size, and disk use;
- claim, challenge, work, mint, burial, and title stages;
- local-work attempts, target, expected work, and winning hash;
- current title outpoint, script type, value, confirmations, and UTXO status;
- sixteen independent verifier gates;
- append-only structured lifecycle telemetry over Server-Sent Events;
- mutated-work and mutated-challenge rejection;
- visible atom invalidation when its challenge block leaves the active chain;
- validity restoration when that history is reconsidered;
- bundled protocol specifications, threat model, issuance simulation, proof JSON, and validation transcript.

The browser has no third-party JavaScript, fonts, analytics, trackers, CDNs, or remote asset calls.

## Three truthfully distinct modes

### 1. Preserved Core replay — works immediately

This mode replays the evidence from the completed 2026-09-02 Bitcoin Core regtest validation. It is animated and inspectable, but clearly labelled **recorded replay**, not current node activity.

```bash
python3 -m goldatom_observatory serve
```

Then open `http://127.0.0.1:8787/`.

Double-click on macOS:

```text
START-GOLDATOM.command
```

### 2. Fresh isolated regtest lab — genuinely live

This starts a private Bitcoin Core regtest node, creates a fresh GoldAtom, and leaves the node running for continuous reassay. It uses only valueless regtest coins and does not touch an existing node or wallet.

```bash
python3 -m goldatom_observatory lab \
  --bitcoind /absolute/path/to/bitcoind
```

Or:

```bash
BITCOIND=/absolute/path/to/bitcoind ./START-LIVE-LAB.command
```

The lab creates a timestamped directory under `goldatom-runs/` containing:

- the private regtest datadir;
- lifecycle JSONL telemetry;
- the portable `.goldatom.json` proof bundle;
- Bitcoin Core stdout/stderr;
- lifecycle stdout/stderr;
- the exact `bitcoind --version` output;
- SHA-256 of the binary used.

Press **MINT TEST ATOM** in the site to execute another lifecycle against the same private node.

### 3. Attach to an existing Bitcoin Core node — live read-only assay

```bash
python3 -m goldatom_observatory serve --mode core \
  --rpc-url http://127.0.0.1:18443 \
  --cookie-file "$HOME/.bitcoin/regtest/.cookie" \
  --bundle /path/to/atom.goldatom.json
```

Core-monitor mode uses read-only RPC calls. The isolated lab is the only mode that creates blocks or transactions, and it refuses any chain other than `regtest`.

## Install

The source tree has no runtime dependencies outside the Python standard library.

```bash
python3 -m pip install goldatom_observatory-0.1.0-py3-none-any.whl
goldatom-observatory serve
```

Python 3.11 or newer is required.

## One-command launchers

```bash
./start-observatory.sh replay
./start-observatory.sh lab /absolute/path/to/bitcoind
```

The shell scripts create no virtual environment and install nothing. They execute the checked-out source directly.

## HTTP surface

| Route | Purpose |
|---|---|
| `/` | Observatory interface |
| `/api/state` | Complete current instrument state |
| `/api/events` | Server-Sent Events stream |
| `/api/bundle` | Loaded portable proof bundle |
| `/api/health` | Minimal health state |
| `/api/action/verify` | Force immediate reassay |
| `/api/action/replay` | Restart preserved replay |
| `/api/action/speed` | Change replay rate |
| `/api/action/run` | Start a fresh lifecycle in isolated lab mode |
| `/docs/<name>` | Read bundled protocol documents |
| `/download/<category>/<name>` | Download bundled evidence or documents |

State-changing local actions require the `X-GoldAtom-Action: 1` request header. This is an accidental-request guard, **not network authentication**.

## Security posture

The default listener is `127.0.0.1`; keep it that way for ordinary use. The application deliberately has no user or session model. The CLI refuses non-loopback binding unless `--unsafe-public` is supplied. Before using that override or exposing the site through a tunnel, put it behind authenticated TLS and restrict Bitcoin RPC independently.

RPC credentials are used server-side and never included in API responses or browser code. Cookie authentication is preferred. The lab creates its own private datadir and cookie.

See [SECURITY.md](SECURITY.md) for the precise trust boundaries.

## Verify the release

```bash
sha256sum -c GOLDATOM-OBSERVATORY-0.1.0-SHA256SUMS.txt
python3 -m unittest discover -v
python3 -m compileall -q goldatom goldatom_observatory scripts tests
node --check goldatom_observatory/static/app.js
```

A complete validation record is included in `OBSERVATORY-VALIDATION.md`.

## Design boundary

The site proves that a coherent GoldAtom object can be constructed, buried, reassayed, invalidated by removal of its committed Bitcoin history, and restored when that history returns. It does not prove that GoldAtom/1 has solved aggregate scarcity, equitable distribution, miner manipulation, or monetary adoption.

The surviving issuance research direction remains:

```text
global claimant-independent proof intersection
  → one canonical vein
  → Bit-Gold extraction contest
  → one Bitcoin title
```

GoldAtom/0 is the object layer. GoldAtom/1 remains a candidate monetary-physics layer.

## License

MIT. Copyright © 2026 Jcb.
