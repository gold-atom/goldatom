from __future__ import annotations

import json
import tempfile
import threading
import time
import unittest
from copy import deepcopy
import urllib.error
import urllib.request
from pathlib import Path

from goldatom.models import GoldAtomBundle
from goldatom_observatory.app import ObservatoryApplication
from goldatom_observatory.cli import _enforce_bind_policy, _is_loopback_host
from goldatom_observatory.diagnostics import offline_checks, offline_facts
from goldatom_observatory.events import EventBus
from goldatom_observatory.evidence import Evidence
from goldatom_observatory.journal import JournalTailer, JournalWriter
from goldatom_observatory.replay import ReplayMonitor
from goldatom_observatory.server import ObservatoryHTTPServer


class EvidenceTests(unittest.TestCase):
    def test_preserved_bundle_recomputes_local_protocol_facts(self) -> None:
        evidence = Evidence.load()
        bundle = GoldAtomBundle.from_dict(evidence.bundle)
        facts = offline_facts(bundle)
        self.assertEqual(
            facts["atom_id"],
            "1f703b02a851b5ab42e5dcfb561799b7eca6ddd52246ddace14cd4d0845f6fa6",
        )
        self.assertTrue(facts["claim_commitment_recomputes"])
        self.assertTrue(facts["challenge_recomputes"])
        self.assertTrue(facts["work_hash_recomputes"])
        self.assertTrue(facts["work_satisfies_target"])
        self.assertTrue(facts["mint_commitment_recomputes"])
        self.assertEqual(facts["attempts"], 18)
        self.assertEqual(len(offline_checks(bundle, recorded_pass=True)), 16)

    def test_research_documents_are_packaged(self) -> None:
        names = {item["name"] for item in Evidence.documents()}
        self.assertIn("SPEC-0.md", names)
        self.assertIn("SPEC-1-CANDIDATE.md", names)
        self.assertIn("FINAL-VALIDATION-TRANSCRIPT.md", names)


class EventTests(unittest.TestCase):
    def test_event_ids_are_monotonic_and_queryable(self) -> None:
        bus = EventBus(capacity=10)
        first = bus.publish("one", "One")
        second = bus.publish("two", "Two", level="success")
        self.assertEqual((first.id, second.id), (1, 2))
        self.assertEqual([event.id for event in bus.after(1)], [2])
        self.assertEqual(bus.latest_id, 2)

    def test_journal_tailer_projects_structured_records(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "events.jsonl"
            bus = EventBus()
            writer = JournalWriter(path)
            tailer = JournalTailer(path, bus)
            writer.emit(
                "work.complete",
                "Work found",
                "A target-satisfying hash was discovered.",
                severity="success",
                stage="work",
                attempts=21,
            )
            tailer.poll()
            snapshot = tailer.snapshot()
            self.assertEqual(snapshot["records"], 1)
            self.assertEqual(snapshot["attempts"], 21)
            event = bus.snapshot()[0]
            self.assertEqual(event["stage"], "work")
            self.assertEqual(event["data"]["attempts"], 21)


class ReplayTests(unittest.TestCase):
    def test_replay_is_truth_labelled_and_reassays_locally(self) -> None:
        bus = EventBus()
        monitor = ReplayMonitor(bus, speed=8, auto_start=False)
        self.addCleanup(monitor.stop)
        state = monitor.get_state()
        self.assertEqual(state["meta"]["mode"], "replay")
        self.assertFalse(state["meta"]["live"])
        self.assertIn("preserved", state["meta"]["truth_label"].lower())
        result = monitor.force_verify()
        self.assertTrue(result["local_valid"])
        self.assertIn("canonicality remains recorded", bus.snapshot()[-1]["message"].lower())

    def test_replay_reset_and_speed(self) -> None:
        bus = EventBus()
        monitor = ReplayMonitor(bus, speed=1, auto_start=False)
        self.addCleanup(monitor.stop)
        self.assertEqual(monitor.set_speed(99), 8.0)
        monitor.reset()
        state = monitor.get_state()
        self.assertEqual(state["meta"]["generation"], 1)
        self.assertEqual(state["meta"]["speed"], 8.0)


class HTTPTests(unittest.TestCase):
    def setUp(self) -> None:
        self.bus = EventBus()
        self.monitor = ReplayMonitor(self.bus, speed=8, auto_start=False)
        self.app = ObservatoryApplication(self.monitor, self.bus)
        self.server = ObservatoryHTTPServer(("127.0.0.1", 0), self.app)
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()
        host, port = self.server.server_address
        self.base = f"http://{host}:{port}"

    def tearDown(self) -> None:
        self.server.shutdown()
        self.server.server_close()
        self.app.close()
        self.thread.join(timeout=2)

    def get_json(self, path: str) -> dict:
        with urllib.request.urlopen(self.base + path, timeout=3) as response:
            self.assertEqual(response.status, 200)
            return json.load(response)

    def test_state_bundle_health_and_security_headers(self) -> None:
        health = self.get_json("/api/health")
        self.assertTrue(health["ok"])
        state = self.get_json("/api/state")
        self.assertEqual(state["meta"]["mode"], "replay")
        bundle = self.get_json("/api/bundle")
        self.assertEqual(bundle["profile"], "goldatom-regtest-v0")
        with urllib.request.urlopen(self.base + "/", timeout=3) as response:
            body = response.read().decode()
            self.assertIn("GoldAtom Observatory", body)
            self.assertEqual(response.headers["X-Frame-Options"], "DENY")
            self.assertIn("default-src 'self'", response.headers["Content-Security-Policy"])

    def test_head_request_has_headers_and_no_body(self) -> None:
        req = urllib.request.Request(self.base + "/", method="HEAD")
        with urllib.request.urlopen(req, timeout=3) as response:
            self.assertEqual(response.status, 200)
            self.assertEqual(response.read(), b"")
            self.assertEqual(response.headers["X-Frame-Options"], "DENY")

    def test_post_action_requires_local_action_header(self) -> None:
        request = urllib.request.Request(
            self.base + "/api/action/verify",
            data=b"{}",
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with self.assertRaises(urllib.error.HTTPError) as context:
            urllib.request.urlopen(request, timeout=3)
        self.assertEqual(context.exception.code, 403)

    def test_reassay_action(self) -> None:
        request = urllib.request.Request(
            self.base + "/api/action/verify",
            data=b"{}",
            headers={
                "Content-Type": "application/json",
                "X-GoldAtom-Action": "1",
            },
            method="POST",
        )
        with urllib.request.urlopen(request, timeout=3) as response:
            result = json.load(response)
        self.assertTrue(result["ok"])
        self.assertTrue(result["result"]["local_valid"])


class BindPolicyTests(unittest.TestCase):
    def test_loopback_recognition(self) -> None:
        self.assertTrue(_is_loopback_host("127.0.0.1"))
        self.assertTrue(_is_loopback_host("localhost"))
        self.assertTrue(_is_loopback_host("::1"))
        self.assertFalse(_is_loopback_host("0.0.0.0"))

    def test_public_bind_requires_explicit_override(self) -> None:
        with self.assertRaises(SystemExit):
            _enforce_bind_policy("0.0.0.0", unsafe_public=False)
        _enforce_bind_policy("0.0.0.0", unsafe_public=True)


class RuntimeProjectionTests(unittest.TestCase):
    class DummyMonitor:
        def __init__(self) -> None:
            self.state = {
                "meta": {"mode": "core"},
                "atom": {
                    "present": False,
                    "status": "WAITING",
                    "status_detail": "waiting",
                    "claim": {},
                    "challenge": {},
                    "work": {},
                    "mint": {},
                    "burial": {},
                    "title": {},
                },
                "timeline": [
                    {"id": stage, "label": stage.upper(), "status": "pending"}
                    for stage in ("claim", "challenge", "work", "mint", "burial", "title")
                ],
                "negative_checks": {},
                "actions": {},
            }

        def get_state(self):
            return deepcopy(self.state)

        def get_bundle_dict(self):
            return None

        def force_verify(self):
            return {"valid": None}

        def stop(self):
            return None

    def test_inflight_stage_facts_persist_across_later_events(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "events.jsonl"
            bus = EventBus()
            app = ObservatoryApplication(self.DummyMonitor(), bus, journal_path=path)
            writer = JournalWriter(path)
            try:
                writer.emit(
                    "claim.confirmed",
                    "Claim seal confirmed",
                    "The claim is fixed.",
                    severity="success",
                    stage="claim",
                    height=102,
                    block_hash="ab" * 32,
                    outpoint=f"{'cd' * 32}:0",
                )
                writer.emit(
                    "challenge.locked",
                    "Challenge locked by Bitcoin",
                    "Future history is fixed.",
                    severity="signal",
                    stage="challenge",
                    height=105,
                    block_hash="ef" * 32,
                    digest="12" * 32,
                )
                assert app.journal is not None
                app.journal.poll()
                state = app.get_state()
                self.assertEqual(102, state["atom"]["claim"]["height"])
                self.assertEqual(105, state["atom"]["challenge"]["height"])
                self.assertEqual("complete", state["timeline"][0]["status"])
                self.assertEqual("active", state["timeline"][1]["status"])
            finally:
                app.close()


if __name__ == "__main__":
    unittest.main()
